// Smart Canteen – Vanilla JavaScript Core Logic
const INITIAL_MENU = [
  { id: '1', name: 'Steamed Idli (2 Pcs)', price: 20, category: 'Breakfast', prep: 5, emoji: '&#127858;', desc: 'Served with sambar and fresh chutney.' },
  { id: '2', name: 'Crispy Masala Dosa', price: 40, category: 'Breakfast', prep: 8, emoji: '&#129367;', desc: 'Golden crepe filled with spiced potato masala.' },
  { id: '3', name: 'Poori Masala (3 Pcs)', price: 35, category: 'Breakfast', prep: 7, emoji: '&#127858;', desc: 'Wheat pooris served with tempered potato bhaji.' },
  { id: '4', name: 'South Indian Veg Meals', price: 80, category: 'Lunch', prep: 10, emoji: '&#127858;', desc: 'Full thali with rice, sambar, rasam, curd, and papad.' },
  { id: '5', name: 'Veg Fried Rice', price: 70, category: 'Lunch', prep: 12, emoji: '&#127834;', desc: 'Wok-tossed basmati rice with crunchy vegetables.' },
  { id: '6', name: 'Grilled Veg Club Sandwich', price: 40, category: 'Snacks', prep: 6, emoji: '&#129386;', desc: 'Toasted with fresh veggies, mint chutney, and cheese.' },
  { id: '7', name: 'Canteen Crispy Veg Burger', price: 60, category: 'Fast Food', prep: 8, emoji: '&#127828;', desc: 'Crispy potato patty with lettuce and burger sauce.' },
  { id: '8', name: 'Special Masala Chai', price: 10, category: 'Beverages', prep: 3, emoji: '&#9749;', desc: 'Fresh brewed ginger and cardamom milk tea.' },
  { id: '9', name: 'South Indian Filter Coffee', price: 15, category: 'Beverages', prep: 4, emoji: '&#9749;', desc: 'Decoction coffee poured with frothy milk.' },
  { id: '10', name: 'Fresh Fruit Juice', price: 30, category: 'Beverages', prep: 5, emoji: '&#129380;', desc: 'Chilled seasonal fruit juice pressed fresh.' }
];

let cart = JSON.parse(localStorage.getItem('canteen_cart') || '[]');
let orders = JSON.parse(localStorage.getItem('canteen_orders') || '[]');
let currentToken = localStorage.getItem('canteen_current_token') || 'CT-101';
let currentCategory = 'All';

// Save to storage
function saveState() {
  localStorage.setItem('canteen_cart', JSON.stringify(cart));
  localStorage.setItem('canteen_orders', JSON.stringify(orders));
  updateUI();
}

function updateUI() {
  updateCartBadge();
  renderTracker();
  renderAdmin();
  renderHistory();
}

function updateCartBadge() {
  const totalQty = cart.reduce((s, c) => s + c.qty, 0);
  const badge = document.getElementById('cartCountBadge');
  if (badge) badge.innerText = totalQty;
}

function renderMenu() {
  const grid = document.getElementById('foodGrid');
  const search = document.getElementById('searchInput')?.value.toLowerCase() || '';
  if (!grid) return;
  grid.innerHTML = '';

  const filtered = INITIAL_MENU.filter(item => {
    if (currentCategory !== 'All' && item.category !== currentCategory) return false;
    if (search && !item.name.toLowerCase().includes(search)) return false;
    return true;
  });

  filtered.forEach(item => {
    const card = document.createElement('div');
    card.className = 'food-card';
    card.innerHTML = `
      <div class="food-img-ph">${item.emoji}</div>
      <div class="food-card-body">
        <div class="food-meta">${item.category} &bull; ${item.prep}m prep</div>
        <h4>${item.name}</h4>
        <p class="food-desc">${item.desc}</p>
        <div class="food-bottom">
          <span class="food-price">₹${item.price}</span>
          <button class="add-btn" onclick="addToCart('${item.id}')">+ Add to Cart</button>
        </div>
      </div>
    `;
    grid.appendChild(card);
  });
}

window.addToCart = function(itemId) {
  const found = INITIAL_MENU.find(i => i.id === itemId);
  if (!found) return;
  const existing = cart.find(c => c.id === itemId);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({ ...found, qty: 1 });
  }
  saveState();
  alert(`${found.name} added to cart!`);
};

function renderCartModal() {
  const list = document.getElementById('cartItemsList');
  const totalText = document.getElementById('cartTotalText');
  if (!list || !totalText) return;
  list.innerHTML = '';

  if (cart.length === 0) {
    list.innerHTML = '<p style="text-align:center; padding:20px; color:#64748B;">Cart is empty!</p>';
    totalText.innerText = '₹0';
    return;
  }

  let total = 0;
  cart.forEach(item => {
    total += item.price * item.qty;
    const row = document.createElement('div');
    row.className = 'cart-item';
    row.innerHTML = `
      <div>
        <strong>${item.name}</strong>
        <div style="font-size:11px; color:#64748B;">₹${item.price} &times; ${item.qty}</div>
      </div>
      <div><strong>₹${item.price * item.qty}</strong></div>
    `;
    list.appendChild(row);
  });
  totalText.innerText = `₹${total}`;
}

function renderTracker() {
  const tokenNum = document.getElementById('tokenDisplayNumber');
  if (tokenNum) tokenNum.innerText = `#${currentToken}`;
}

function renderAdmin() {
  const total = document.getElementById('kpiTotalOrders');
  const sales = document.getElementById('kpiTotalSales');
  if (total) total.innerText = orders.length;
  if (sales) {
    const rev = orders.reduce((s, o) => s + o.total, 0);
    sales.innerText = `₹${rev}`;
  }
}

function renderHistory() {
  const list = document.getElementById('historyList');
  if (!list) return;
  list.innerHTML = '';
  if (orders.length === 0) {
    list.innerHTML = '<p style="color:#64748B; font-size:13px;">No past orders yet.</p>';
    return;
  }
  orders.forEach(o => {
    const div = document.createElement('div');
    div.style = 'background:#FFF; padding:12px; border-radius:12px; margin-bottom:10px; border:1px solid #E2E8F0;';
    div.innerHTML = `<strong>Token #${o.token}</strong> - ₹${o.total} (${o.status})`;
    list.appendChild(div);
  });
}

// Tab navigation
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const tab = btn.dataset.tab;

    document.querySelectorAll('.view-section').forEach(sec => sec.classList.remove('active'));
    if (tab === 'menu') document.getElementById('viewMenu')?.classList.add('active');
    if (tab === 'tracker') document.getElementById('viewTracker')?.classList.add('active');
    if (tab === 'history') document.getElementById('viewHistory')?.classList.add('active');
    if (tab === 'admin') document.getElementById('viewAdmin')?.classList.add('active');
  });
});

// Category filtering
document.querySelectorAll('.cat-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentCategory = btn.dataset.cat;
    renderMenu();
  });
});

document.getElementById('searchInput')?.addEventListener('input', renderMenu);

// Cart Modal open/close
const cartModal = document.getElementById('cartModal');
document.getElementById('cartBtn')?.addEventListener('click', () => {
  renderCartModal();
  cartModal?.classList.add('open');
});
document.getElementById('closeCartBtn')?.addEventListener('click', () => {
  cartModal?.classList.remove('open');
});

// Checkout action
document.getElementById('checkoutBtn')?.addEventListener('click', () => {
  if (cart.length === 0) return alert('Cart is empty!');
  const nextToken = 'CT-' + Math.floor(100 + Math.random() * 900);
  const total = cart.reduce((s, c) => s + c.price * c.qty, 0);
  orders.unshift({ token: nextToken, total, status: 'Preparing', date: new Date().toLocaleTimeString() });
  currentToken = nextToken;
  localStorage.setItem('canteen_current_token', nextToken);
  cart = [];
  saveState();
  cartModal?.classList.remove('open');
  alert(`Order Placed Successfully! Your Digital Token is #${nextToken}`);
  
  // Switch to tracker tab
  document.querySelector('[data-tab="tracker"]')?.click();
});

// Initial boot
window.addEventListener('DOMContentLoaded', () => {
  renderMenu();
  updateUI();
});
