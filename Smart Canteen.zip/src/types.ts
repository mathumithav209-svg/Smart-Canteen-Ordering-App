export type UserRole = 'student' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  rollNumber?: string;
}

export type FoodCategory = 'All' | 'Breakfast' | 'Lunch' | 'Snacks' | 'Beverages' | 'Fast Food';

export interface FoodItem {
  id: string;
  name: string;
  category: Exclude<FoodCategory, 'All'>;
  price: number;
  description: string;
  image: string;
  available: boolean;
  prepTimeMinutes: number;
  isVeg: boolean;
  isSpecial?: boolean;
  calories?: string;
  rating?: number;
}

export interface CartItem {
  item: FoodItem;
  quantity: number;
  specialNote?: string;
}

export type OrderStatus = 'placed' | 'accepted' | 'preparing' | 'ready' | 'completed';

export interface OrderStatusHistory {
  status: OrderStatus;
  timestamp: string;
  label: string;
}

export interface Order {
  id: string;
  tokenNumber: string; // e.g. "CT-101"
  userId: string;
  userName: string;
  userPhone: string;
  rollNumber?: string;
  items: CartItem[];
  subtotal: number;
  convenienceFee: number;
  total: number;
  paymentMethod: 'cash' | 'upi';
  paymentStatus: 'pending' | 'completed';
  status: OrderStatus;
  pickupCounter: string;
  createdAt: string;
  estimatedMinutes: number;
  specialInstructions?: string;
  history: OrderStatusHistory[];
}

export interface CanteenNotification {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'order_status' | 'order_placed' | 'info';
  orderId?: string;
  tokenNumber?: string;
}
