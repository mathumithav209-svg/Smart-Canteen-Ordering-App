import React, { useState } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { 
  X, 
  CheckCircle2, 
  QrCode, 
  Smartphone, 
  Banknote, 
  ShieldAlert, 
  Clock, 
  Sparkles,
  ArrowRight,
  Loader2
} from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({ isOpen, onClose }) => {
  const { 
    currentUser, 
    cart, 
    cartSubtotal, 
    placeOrder, 
    setIsAuthModalOpen 
  } = useCanteen();

  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'upi'>('upi');
  const [upiProvider, setUpiProvider] = useState<'gpay' | 'phonepe' | 'paytm' | 'qr'>('gpay');
  const [instructions, setInstructions] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [createdToken, setCreatedToken] = useState('');

  if (!isOpen) return null;

  const totalAmount = cartSubtotal;

  const handleConfirmOrder = () => {
    setIsProcessing(true);

    // Simulate payment processing delay (1.2s)
    setTimeout(() => {
      const order = placeOrder(paymentMethod, instructions);
      setCreatedToken(order.tokenNumber);
      setIsProcessing(false);
      setIsSuccess(true);
    }, 1200);
  };

  const handleFinish = () => {
    setIsSuccess(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-orange-100 overflow-hidden relative"
        onClick={e => e.stopPropagation()}
      >
        {/* Success View */}
        {isSuccess ? (
          <div className="p-8 text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner animate-in zoom-in-50 duration-300">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                Order Confirmed!
              </span>
              <h3 className="text-2xl font-extrabold text-slate-900 mt-2">
                Order Token #{createdToken}
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Your order was successfully sent to the canteen kitchen master. Keep this digital token ready at the pickup counter.
              </p>
            </div>

            {/* Token Badge Showcase */}
            <div className="bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-dashed border-orange-300 rounded-2xl p-4 flex flex-col items-center">
              <span className="text-[11px] font-semibold text-orange-800">
                DIGITAL QUEUE TOKEN
              </span>
              <span className="font-mono text-4xl font-black text-orange-600 tracking-wider my-1">
                {createdToken}
              </span>
              <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium mt-1">
                <Clock className="w-3.5 h-3.5 text-orange-500" />
                <span>Estimated Prep Time: ~10-12 mins</span>
              </div>
            </div>

            <button
              onClick={handleFinish}
              className="w-full py-3 bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm rounded-xl shadow-md shadow-orange-500/20 transition-all flex items-center justify-center gap-2"
            >
              <span>View Live Progress Tracker</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        ) : (
          /* Normal Checkout View */
          <div>
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-orange-500 to-amber-600 px-6 py-4 text-white flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold">Confirm & Place Order</h3>
                <p className="text-xs text-orange-100">Review canteen pickup details and payment</p>
              </div>
              <button
                onClick={onClose}
                disabled={isProcessing}
                className="p-1 rounded-full hover:bg-white/20 transition-colors text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
              {/* Demo Mode Notice */}
              <div className="p-3 bg-amber-50 border border-amber-200/80 rounded-xl flex items-start gap-2.5 text-xs text-amber-900">
                <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-semibold">Simulated Payment Mode:</strong> This is a college mini-project demonstration. No real bank accounts or money are debited.
                </div>
              </div>

              {/* Student Details Card */}
              <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3.5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">Student Profile</span>
                  {!currentUser && (
                    <button
                      onClick={() => setIsAuthModalOpen(true)}
                      className="text-xs font-semibold text-orange-600 underline"
                    >
                      Login for Student ID
                    </button>
                  )}
                </div>
                <div className="text-xs text-slate-600 grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Name</span>
                    <strong className="text-slate-800">{currentUser?.name || 'Walk-in Student'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Roll No / Phone</span>
                    <strong className="text-slate-800">
                      {currentUser?.rollNumber || '23CS012'} · {currentUser?.phone || '9845012345'}
                    </strong>
                  </div>
                </div>
              </div>

              {/* Special Cooking Instructions */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Kitchen Notes / Special Requests (Optional)
                </label>
                <input
                  type="text"
                  value={instructions}
                  onChange={e => setInstructions(e.target.value)}
                  placeholder="e.g. Less spicy sambar, extra hot coffee, no ice in juice"
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:border-orange-500 focus:bg-white"
                />
              </div>

              {/* Payment Method Selection */}
              <div className="space-y-3">
                <label className="block text-xs font-bold text-slate-700">
                  Select Payment Option
                </label>

                <div className="grid grid-cols-2 gap-3">
                  {/* Demo UPI Button */}
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('upi')}
                    className={`p-3 rounded-2xl border text-left transition-all ${
                      paymentMethod === 'upi'
                        ? 'border-orange-500 bg-orange-50/50 ring-2 ring-orange-500/10'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <Smartphone className={`w-4 h-4 ${paymentMethod === 'upi' ? 'text-orange-600' : 'text-slate-500'}`} />
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                        Fastest
                      </span>
                    </div>
                    <span className="block text-xs font-bold text-slate-800">Demo UPI Payment</span>
                    <span className="block text-[10px] text-slate-500">GPay, PhonePe, QR Code</span>
                  </button>

                  {/* Cash at Counter Button */}
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('cash')}
                    className={`p-3 rounded-2xl border text-left transition-all ${
                      paymentMethod === 'cash'
                        ? 'border-orange-500 bg-orange-50/50 ring-2 ring-orange-500/10'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <Banknote className={`w-4 h-4 ${paymentMethod === 'cash' ? 'text-orange-600' : 'text-slate-500'}`} />
                    </div>
                    <span className="block text-xs font-bold text-slate-800">Cash at Counter</span>
                    <span className="block text-[10px] text-slate-500">Pay cash upon food pickup</span>
                  </button>
                </div>

                {/* Sub-options for UPI */}
                {paymentMethod === 'upi' && (
                  <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                    <span className="text-[11px] font-semibold text-slate-600 block">
                      Choose Simulated UPI Method:
                    </span>
                    <div className="grid grid-cols-4 gap-2">
                      <button
                        type="button"
                        onClick={() => setUpiProvider('gpay')}
                        className={`p-2 rounded-xl border text-center transition-all ${
                          upiProvider === 'gpay'
                            ? 'bg-blue-50 border-blue-500 text-blue-700 font-bold'
                            : 'bg-white border-slate-200 text-slate-600 text-xs'
                        }`}
                      >
                        <span className="text-xs block font-bold">GPay</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setUpiProvider('phonepe')}
                        className={`p-2 rounded-xl border text-center transition-all ${
                          upiProvider === 'phonepe'
                            ? 'bg-purple-50 border-purple-500 text-purple-700 font-bold'
                            : 'bg-white border-slate-200 text-slate-600 text-xs'
                        }`}
                      >
                        <span className="text-xs block font-bold">PhonePe</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setUpiProvider('paytm')}
                        className={`p-2 rounded-xl border text-center transition-all ${
                          upiProvider === 'paytm'
                            ? 'bg-cyan-50 border-cyan-500 text-cyan-700 font-bold'
                            : 'bg-white border-slate-200 text-slate-600 text-xs'
                        }`}
                      >
                        <span className="text-xs block font-bold">Paytm</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setUpiProvider('qr')}
                        className={`p-2 rounded-xl border text-center transition-all ${
                          upiProvider === 'qr'
                            ? 'bg-orange-50 border-orange-500 text-orange-700 font-bold'
                            : 'bg-white border-slate-200 text-slate-600 text-xs'
                        }`}
                      >
                        <span className="text-xs block font-bold">Scan QR</span>
                      </button>
                    </div>

                    {upiProvider === 'qr' ? (
                      <div className="flex flex-col items-center justify-center p-3 bg-white rounded-xl border border-slate-200 text-center">
                        <QrCode className="w-20 h-20 text-slate-800 mb-1" />
                        <span className="text-[11px] font-mono text-slate-600">UPI ID: canteen@college</span>
                        <span className="text-[10px] text-slate-400">Click button below to simulate successful scan</span>
                      </div>
                    ) : (
                      <div className="text-[11px] text-slate-500 bg-white p-2.5 rounded-xl border border-slate-200 flex items-center justify-between">
                        <span>Canteen Merchant: <strong>CAMPUS-CANTEEN-01</strong></span>
                        <span className="text-emerald-700 font-semibold">Ready to Pay</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Order Bill Breakdown */}
              <div className="border-t border-slate-200 pt-3 space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Items Total ({cart.reduce((s, c) => s + c.quantity, 0)} items)</span>
                  <span className="font-mono">₹{cartSubtotal}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Digital Token & Packaging Fee</span>
                  <span className="font-semibold text-emerald-600">FREE (₹0)</span>
                </div>
                <div className="flex justify-between font-bold text-sm text-slate-900 pt-2 border-t border-slate-200">
                  <span>Payable Amount</span>
                  <span className="font-mono text-base text-orange-600">₹{totalAmount}</span>
                </div>
              </div>

              {/* Confirm Button */}
              <button
                type="button"
                onClick={handleConfirmOrder}
                disabled={isProcessing}
                className="w-full py-3.5 bg-orange-500 hover:bg-orange-600 disabled:bg-orange-300 text-white font-bold text-sm rounded-xl shadow-lg shadow-orange-500/25 transition-all flex items-center justify-center gap-2"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Processing Demo Payment...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-200" />
                    <span>
                      {paymentMethod === 'upi' ? `Simulate Pay ₹${totalAmount}` : `Confirm Order (Pay Cash ₹${totalAmount})`}
                    </span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
