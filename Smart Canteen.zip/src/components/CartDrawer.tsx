import React, { useState } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { 
  ShoppingBag, 
  Trash2, 
  Plus, 
  Minus, 
  ArrowRight, 
  Clock, 
  Utensils, 
  ShieldCheck,
  ChevronLeft
} from 'lucide-react';
import { CheckoutModal } from './CheckoutModal';

export const CartDrawer: React.FC = () => {
  const { 
    cart, 
    cartSubtotal, 
    cartTotalCount, 
    updateCartQuantity, 
    removeFromCart, 
    clearCart,
    setActiveTab 
  } = useCanteen();

  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  // Estimated prep time calculation
  const maxPrepTime = cart.length > 0 
    ? Math.max(...cart.map(c => c.item.prepTimeMinutes), 5) + 2
    : 0;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Breadcrumb & Title */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveTab('menu')}
          className="text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back to Food Menu</span>
        </button>

        {cart.length > 0 && (
          <button
            onClick={clearCart}
            className="text-xs text-red-600 hover:text-red-700 font-semibold"
          >
            Clear Cart
          </button>
        )}
      </div>

      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center">
          <ShoppingBag className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900">Your Canteen Cart</h2>
          <p className="text-xs text-slate-500">
            {cartTotalCount} {cartTotalCount === 1 ? 'item' : 'items'} selected for ordering
          </p>
        </div>
      </div>

      {cart.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-4">
          <div className="w-20 h-20 rounded-full bg-orange-50 text-orange-400 flex items-center justify-center mx-auto">
            <Utensils className="w-10 h-10" />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-slate-900">Your Cart is Empty</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              You haven&apos;t added any food items yet. Browse today&apos;s breakfast, meals, snacks, or beverages!
            </p>
          </div>
          <button
            onClick={() => setActiveTab('menu')}
            className="px-5 py-2.5 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs rounded-xl shadow-md transition-colors"
          >
            Browse Food Menu
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Items List (2 cols) */}
          <div className="lg:col-span-2 space-y-3">
            {cart.map(({ item, quantity }) => (
              <div
                key={item.id}
                className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs hover:border-orange-200 transition-colors flex gap-4 items-center"
              >
                {/* Food Thumbnail */}
                <div className="w-20 h-20 rounded-xl overflow-hidden bg-orange-50 shrink-0">
                  <img
                    src={item.image}
                    alt={item.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                </div>

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-medium">
                    <span className="w-2 h-2 rounded-full bg-emerald-600" />
                    <span>{item.category}</span>
                    <span>·</span>
                    <span>{item.prepTimeMinutes}m prep</span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-900 truncate mt-0.5">
                    {item.name}
                  </h4>

                  <div className="flex items-center gap-2 mt-1">
                    <span className="font-mono text-sm font-extrabold text-slate-900">
                      ₹{item.price * quantity}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      (₹{item.price} each)
                    </span>
                  </div>
                </div>

                {/* Quantity Controls & Delete */}
                <div className="flex flex-col items-end gap-2 shrink-0">
                  <div className="flex items-center gap-2 bg-slate-100 rounded-xl p-1">
                    <button
                      onClick={() => updateCartQuantity(item.id, -1)}
                      className="w-7 h-7 flex items-center justify-center text-slate-700 hover:bg-white rounded-lg transition-colors"
                      aria-label="Decrease quantity"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="font-mono text-sm font-bold text-slate-900 w-5 text-center">
                      {quantity}
                    </span>
                    <button
                      onClick={() => updateCartQuantity(item.id, 1)}
                      className="w-7 h-7 flex items-center justify-center text-slate-700 hover:bg-white rounded-lg transition-colors"
                      aria-label="Increase quantity"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="text-slate-400 hover:text-red-500 p-1 transition-colors"
                    title="Remove item"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}

            {/* Quick Suggestions / Add More */}
            <div className="bg-orange-50/60 border border-orange-200/60 rounded-2xl p-3.5 flex items-center justify-between">
              <span className="text-xs font-medium text-orange-950">
                Want to add hot coffee, tea, or extra snacks?
              </span>
              <button
                onClick={() => setActiveTab('menu')}
                className="text-xs font-bold text-orange-600 hover:text-orange-700 underline shrink-0"
              >
                + Add More Items
              </button>
            </div>
          </div>

          {/* Order Summary Card (1 col) */}
          <div className="space-y-4">
            <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-4">
              <h3 className="text-base font-bold text-slate-900 pb-2 border-b border-slate-100">
                Order Summary
              </h3>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal ({cartTotalCount} items)</span>
                  <span className="font-mono font-medium">₹{cartSubtotal}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Digital Token & Queue Booking</span>
                  <span className="text-emerald-600 font-semibold">FREE (₹0)</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Campus Subsidy / Discount</span>
                  <span className="text-emerald-600 font-semibold">Applied</span>
                </div>

                <div className="border-t border-slate-100 pt-3 flex justify-between items-baseline font-bold text-slate-900">
                  <span className="text-sm">Total Payable</span>
                  <span className="font-mono text-xl text-orange-600">₹{cartSubtotal}</span>
                </div>
              </div>

              {/* Estimated Prep Callout */}
              <div className="p-3 bg-slate-50 rounded-xl flex items-center gap-2.5 text-xs text-slate-600">
                <Clock className="w-4 h-4 text-orange-500 shrink-0" />
                <span>Estimated Kitchen Prep: <strong>~{maxPrepTime} mins</strong></span>
              </div>

              <button
                onClick={() => setIsCheckoutOpen(true)}
                className="w-full py-3.5 bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm rounded-xl shadow-lg shadow-orange-500/25 transition-all flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98]"
              >
                <span>Proceed to Order (₹{cartSubtotal})</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Simulated UPI & Counter Cash Supported</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
      />
    </div>
  );
};
