import React, { useState, useMemo } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { FoodCategory, FoodItem } from '../types';
import { 
  Search, 
  Sparkles, 
  Clock, 
  Flame, 
  Plus, 
  Minus, 
  Check, 
  SlidersHorizontal,
  Coffee,
  X
} from 'lucide-react';

const CATEGORIES: FoodCategory[] = ['All', 'Breakfast', 'Lunch', 'Snacks', 'Beverages', 'Fast Food'];

export const StudentDashboard: React.FC = () => {
  const { 
    currentUser, 
    menu, 
    cart, 
    addToCart, 
    updateCartQuantity, 
    setActiveTab, 
    setIsAuthModalOpen 
  } = useCanteen();

  const [selectedCategory, setSelectedCategory] = useState<FoodCategory>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [onlySpecials, setOnlySpecials] = useState(false);
  const [addedAnimationId, setAddedAnimationId] = useState<string | null>(null);

  // Filter items
  const filteredItems = useMemo(() => {
    return menu.filter(item => {
      // Category filter
      if (selectedCategory !== 'All' && item.category !== selectedCategory) {
        return false;
      }
      // Search filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(q);
        const matchesDesc = item.description.toLowerCase().includes(q);
        const matchesCat = item.category.toLowerCase().includes(q);
        if (!matchesName && !matchesDesc && !matchesCat) return false;
      }
      // Availability filter
      if (onlyAvailable && !item.available) {
        return false;
      }
      // Specials filter
      if (onlySpecials && !item.isSpecial) {
        return false;
      }
      return true;
    });
  }, [menu, selectedCategory, searchQuery, onlyAvailable, onlySpecials]);

  // Today's special items
  const specialItems = useMemo(() => {
    return menu.filter(item => item.isSpecial && item.available);
  }, [menu]);

  // Helper to check cart qty
  const getCartQuantity = (itemId: string) => {
    const found = cart.find(ci => ci.item.id === itemId);
    return found ? found.quantity : 0;
  };

  const handleAddWithFeedback = (item: FoodItem) => {
    addToCart(item);
    setAddedAnimationId(item.id);
    setTimeout(() => {
      setAddedAnimationId(null);
    }, 900);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Welcome Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 p-6 sm:p-8 text-white shadow-xl shadow-orange-500/10 overflow-hidden">
        {/* Subtle decorative background circles */}
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 rounded-full bg-white/10 blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-12 w-48 h-48 rounded-full bg-amber-400/20 blur-xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-semibold text-white tracking-wide">
            <Sparkles className="w-3.5 h-3.5 text-amber-200" />
            <span>Digital Canteen Express</span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight leading-tight text-balance">
            {currentUser 
              ? `Welcome back, ${currentUser.name.split(' ')[0]}!` 
              : 'Order Fresh College Food Without The Waiting Line'}
          </h1>

          <p className="text-orange-100 text-sm sm:text-base leading-relaxed">
            Browse today&apos;s freshly prepared dishes, customize your meal, order online, and pick up using your unique digital token.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => {
                const el = document.getElementById('food-menu-section');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-5 py-2.5 bg-white text-orange-600 hover:bg-orange-50 font-bold text-sm rounded-xl shadow-md transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              Explore Menu
            </button>

            {!currentUser && (
              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="px-4 py-2.5 bg-orange-700/60 hover:bg-orange-700 text-white font-medium text-sm rounded-xl backdrop-blur-sm transition-colors border border-white/20"
              >
                Sign In with Student ID
              </button>
            )}

            <div className="flex items-center gap-4 text-xs font-medium text-orange-100 ml-auto sm:ml-2">
              <span className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-200" />
                Avg. Prep: 8-12 mins
              </span>
              <span className="hidden sm:inline">·</span>
              <span className="hidden sm:inline">Counters 1, 2 & 3 Open</span>
            </div>
          </div>
        </div>
      </div>

      {/* Daily Specials / Chef Recommendations Bar */}
      {specialItems.length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-orange-500 fill-orange-500" />
              <h2 className="text-lg font-bold text-slate-900">Today&apos;s Canteen Specials</h2>
            </div>
            <button 
              onClick={() => {
                setOnlySpecials(prev => !prev);
              }}
              className="text-xs font-semibold text-orange-600 hover:text-orange-700 underline"
            >
              {onlySpecials ? 'Show All Items' : 'Filter Specials'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {specialItems.slice(0, 4).map(item => {
              const qty = getCartQuantity(item.id);
              return (
                <div 
                  key={item.id}
                  className="group bg-white rounded-2xl p-3 border border-orange-200/80 hover:border-orange-300 shadow-xs hover:shadow-md transition-all flex gap-3 items-center"
                >
                  <div className="w-20 h-20 rounded-xl overflow-hidden bg-orange-100 shrink-0 relative">
                    <img 
                      src={item.image} 
                      alt={item.name} 
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                    <div className="absolute top-1 left-1 bg-amber-500 text-white text-[9px] font-bold px-1 py-0.5 rounded leading-none">
                      Chef Pick
                    </div>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1 text-[11px] text-slate-500 mb-0.5">
                      <span>{item.category}</span>
                      <span>·</span>
                      <span>{item.prepTimeMinutes}m prep</span>
                    </div>
                    <h4 className="text-sm font-bold text-slate-900 truncate">{item.name}</h4>
                    <div className="flex items-center justify-between mt-1">
                      <span className="font-mono text-sm font-extrabold text-slate-900">₹{item.price}</span>
                      
                      {qty > 0 ? (
                        <div className="flex items-center gap-1.5 bg-orange-50 border border-orange-200 rounded-lg p-0.5">
                          <button
                            onClick={() => updateCartQuantity(item.id, -1)}
                            className="w-6 h-6 flex items-center justify-center text-orange-700 hover:bg-orange-200/60 rounded"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-bold text-orange-950 px-1">{qty}</span>
                          <button
                            onClick={() => updateCartQuantity(item.id, 1)}
                            className="w-6 h-6 flex items-center justify-center text-orange-700 hover:bg-orange-200/60 rounded"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => handleAddWithFeedback(item)}
                          className="px-2.5 py-1 text-xs font-bold bg-orange-500 hover:bg-orange-600 text-white rounded-lg shadow-2xs transition-colors flex items-center gap-1"
                        >
                          <Plus className="w-3 h-3" />
                          <span>Add</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Search, Categories & Filters Toolbar */}
      <section id="food-menu-section" className="space-y-4 pt-2">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Search bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search idli, dosa, meals, coffee, burger..."
              className="w-full pl-10 pr-9 py-2.5 text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:border-orange-500 focus:ring-2 focus:ring-orange-500/10 shadow-2xs transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Quick Filters */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
            <button
              onClick={() => setOnlyAvailable(prev => !prev)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors border flex items-center gap-1.5 ${
                onlyAvailable
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                  : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${onlyAvailable ? 'bg-emerald-600' : 'bg-slate-300'}`} />
              In Stock Only
            </button>

            <button
              onClick={() => setOnlySpecials(prev => !prev)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors border flex items-center gap-1.5 ${
                onlySpecials
                  ? 'bg-amber-50 text-amber-800 border-amber-300'
                  : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              Chef Specials
            </button>
          </div>
        </div>

        {/* Category Selector Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-white border border-slate-200/80 rounded-2xl overflow-x-auto shadow-2xs">
          {CATEGORIES.map(cat => {
            const isActive = selectedCategory === cat;
            const count = cat === 'All' 
              ? menu.length 
              : menu.filter(m => m.category === cat).length;

            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-xl whitespace-nowrap transition-all flex items-center gap-2 ${
                  isActive
                    ? 'bg-orange-500 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <span>{cat}</span>
                <span className={`text-[11px] px-1.5 py-0.2 rounded-full font-mono ${
                  isActive ? 'bg-orange-600 text-orange-100' : 'bg-slate-100 text-slate-500'
                }`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* Main Food Items Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between text-xs text-slate-500">
          <span>Showing <strong className="text-slate-800 font-mono">{filteredItems.length}</strong> items in {selectedCategory}</span>
          {onlyAvailable && <span>Filtered by: In Stock</span>}
        </div>

        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8 space-y-3">
            <div className="w-16 h-16 rounded-full bg-orange-50 text-orange-500 flex items-center justify-center mx-auto">
              <Coffee className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-slate-800">No Food Items Found</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Try clearing your search query &quot;{searchQuery}&quot; or adjusting category filters.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
                setOnlyAvailable(false);
                setOnlySpecials(false);
              }}
              className="px-4 py-2 bg-orange-500 text-white text-xs font-semibold rounded-xl hover:bg-orange-600 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredItems.map(item => {
              const qty = getCartQuantity(item.id);
              const isJustAdded = addedAnimationId === item.id;

              return (
                <div
                  key={item.id}
                  className={`bg-white rounded-2xl overflow-hidden border transition-all duration-200 flex flex-col group ${
                    !item.available 
                      ? 'border-slate-200 opacity-75' 
                      : 'border-slate-200/90 hover:border-orange-300 hover:shadow-lg hover:-translate-y-0.5'
                  }`}
                >
                  {/* Food Image Container */}
                  <div className="relative aspect-4/3 bg-orange-50 overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />

                    {/* Styled Fallback container if image isn't loaded */}
                    <div className="absolute inset-0 -z-10 flex flex-col items-center justify-center bg-gradient-to-br from-amber-50 to-orange-100 p-4 text-center">
                      <Coffee className="w-8 h-8 text-orange-400 mb-1" />
                      <span className="text-xs font-semibold text-orange-800">{item.name}</span>
                    </div>

                    {/* Top Badges */}
                    <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                      {/* Veg indicator symbol */}
                      <span className="w-5 h-5 bg-white rounded flex items-center justify-center border border-emerald-600 shadow-2xs" title="100% Vegetarian">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
                      </span>

                      {item.isSpecial && (
                        <span className="px-2 py-0.5 bg-amber-500 text-white text-[10px] font-bold rounded-md shadow-2xs">
                          Special
                        </span>
                      )}
                    </div>

                    {/* Availability Tag */}
                    <div className="absolute top-2.5 right-2.5">
                      {item.available ? (
                        <span className="px-2 py-0.5 bg-emerald-700 text-white text-[10px] font-bold rounded-md shadow-2xs">
                          In Stock
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-slate-800 text-white text-[10px] font-bold rounded-md shadow-2xs">
                          Sold Out
                        </span>
                      )}
                    </div>

                    {/* Bottom gradient scrim with prep time */}
                    <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-slate-950/70 via-slate-950/20 to-transparent p-2.5 flex items-center justify-between text-white text-xs">
                      <span className="flex items-center gap-1 font-medium text-[11px]">
                        <Clock className="w-3.5 h-3.5 text-amber-300" />
                        {item.prepTimeMinutes} mins prep
                      </span>
                      {item.calories && (
                        <span className="text-[11px] text-slate-200">
                          {item.calories}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Card Body */}
                  <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium">
                        <span>{item.category}</span>
                        {item.rating && (
                          <span className="text-amber-600 font-semibold flex items-center gap-0.5">
                            ★ {item.rating}
                          </span>
                        )}
                      </div>

                      <h3 className="text-base font-bold text-slate-900 group-hover:text-orange-600 transition-colors leading-snug">
                        {item.name}
                      </h3>

                      <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                        {item.description}
                      </p>
                    </div>

                    {/* Price and Cart Action */}
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">Price</span>
                        <span className="font-mono text-lg font-extrabold text-slate-900">
                          ₹{item.price}
                        </span>
                      </div>

                      {/* Add Button or Stepper */}
                      {!item.available ? (
                        <button
                          disabled
                          className="px-3 py-1.5 bg-slate-100 text-slate-400 text-xs font-semibold rounded-xl cursor-not-allowed"
                        >
                          Unavailable
                        </button>
                      ) : qty > 0 ? (
                        <div className="flex items-center gap-2 bg-orange-50 border border-orange-200 rounded-xl p-1">
                          <button
                            onClick={() => updateCartQuantity(item.id, -1)}
                            className="w-7 h-7 flex items-center justify-center text-orange-700 hover:bg-orange-200/70 rounded-lg transition-colors"
                            aria-label="Decrease quantity"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="font-mono text-sm font-bold text-orange-950 px-1">
                            {qty}
                          </span>
                          <button
                            onClick={() => updateCartQuantity(item.id, 1)}
                            className="w-7 h-7 flex items-center justify-center text-orange-700 hover:bg-orange-200/70 rounded-lg transition-colors"
                            aria-label="Increase quantity"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => handleAddWithFeedback(item)}
                          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                            isJustAdded
                              ? 'bg-emerald-600 text-white shadow-md'
                              : 'bg-orange-500 hover:bg-orange-600 text-white shadow-md shadow-orange-500/20 active:scale-95'
                          }`}
                        >
                          {isJustAdded ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>Added</span>
                            </>
                          ) : (
                            <>
                              <Plus className="w-3.5 h-3.5" />
                              <span>Add to Cart</span>
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Floating Cart Indicator Bar if items in cart */}
      {cart.length > 0 && (
        <div className="fixed bottom-6 right-6 z-30">
          <button
            onClick={() => setActiveTab('cart')}
            className="flex items-center gap-3 px-5 py-3.5 bg-slate-900 text-white rounded-2xl shadow-2xl hover:bg-black transition-all hover:scale-105 border border-slate-700"
          >
            <div className="w-8 h-8 rounded-xl bg-orange-500 flex items-center justify-center font-bold text-xs text-white">
              {cart.reduce((s, c) => s + c.quantity, 0)}
            </div>
            <div className="text-left">
              <span className="block text-xs font-medium text-slate-300">View Canteen Cart</span>
              <span className="block text-sm font-bold font-mono text-amber-400">
                ₹{cart.reduce((s, c) => s + c.item.price * c.quantity, 0)} Total
              </span>
            </div>
          </button>
        </div>
      )}
    </div>
  );
};
