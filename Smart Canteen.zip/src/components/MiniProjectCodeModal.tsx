import React, { useState } from 'react';
import { 
  X, 
  Copy, 
  Check, 
  Download, 
  FileCode, 
  BookOpen, 
  CheckCircle2, 
  Layers,
  Sparkles
} from 'lucide-react';

interface MiniProjectCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MiniProjectCodeModal: React.FC<MiniProjectCodeModalProps> = ({ isOpen, onClose }) => {
  const [activeFile, setActiveFile] = useState<'index.html' | 'style.css' | 'app.js' | 'docs'>('docs');
  const [copiedFile, setCopiedFile] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (fileName: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedFile(fileName);
    setTimeout(() => setCopiedFile(null), 2000);
  };

  const handleDownloadFile = (filename: string, content: string, mime: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-xs">
      <div 
        className="bg-white rounded-3xl max-w-4xl w-full h-[85vh] shadow-2xl border border-orange-100 flex flex-col overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 p-5 text-white flex items-center justify-between border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-500/20 border border-orange-500/30 flex items-center justify-center text-orange-400">
              <FileCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold flex items-center gap-2">
                College Mini-Project Submission Package
                <span className="text-[10px] bg-orange-500 text-white px-2 py-0.5 rounded font-mono">
                  3 Standalone Files
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                HTML, CSS & JavaScript files ready for VS Code Live Server demonstration
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="bg-slate-100 px-6 py-2.5 border-b border-slate-200 flex items-center justify-between overflow-x-auto gap-2">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveFile('docs')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeFile === 'docs'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Project Viva & Documentation</span>
            </button>

            <button
              onClick={() => setActiveFile('index.html')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all ${
                activeFile === 'index.html'
                  ? 'bg-orange-500 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              index.html
            </button>

            <button
              onClick={() => setActiveFile('style.css')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all ${
                activeFile === 'style.css'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              style.css
            </button>

            <button
              onClick={() => setActiveFile('app.js')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all ${
                activeFile === 'app.js'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              app.js
            </button>
          </div>

          {activeFile !== 'docs' && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  const content = activeFile === 'index.html' ? STANDALONE_HTML : activeFile === 'style.css' ? STANDALONE_CSS : STANDALONE_JS;
                  handleCopy(activeFile, content);
                }}
                className="px-2.5 py-1 text-xs font-medium bg-white hover:bg-slate-50 border border-slate-200 rounded-lg text-slate-700 flex items-center gap-1"
              >
                {copiedFile === activeFile ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  const content = activeFile === 'index.html' ? STANDALONE_HTML : activeFile === 'style.css' ? STANDALONE_CSS : STANDALONE_JS;
                  const mime = activeFile === 'index.html' ? 'text/html' : activeFile === 'style.css' ? 'text/css' : 'application/javascript';
                  handleDownloadFile(activeFile, content, mime);
                }}
                className="px-2.5 py-1 text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white rounded-lg flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download</span>
              </button>
            </div>
          )}
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-950 font-mono text-xs text-slate-300">
          {activeFile === 'docs' ? (
            <div className="font-sans space-y-6 text-slate-200 text-sm">
              <div className="p-4 bg-orange-500/10 border border-orange-500/30 rounded-2xl space-y-2">
                <span className="text-xs font-bold text-orange-400 uppercase tracking-wider block">
                  Academic Project Specifications
                </span>
                <h4 className="text-lg font-bold text-white">
                  Smart Canteen – Online Food Ordering System
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Developed to minimize wait time, reduce crowding during peak recess/lunch breaks, and modernize college food court logistics using digital queue tokens and contactless simulated checkout.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-1.5">
                  <span className="text-xs font-bold text-emerald-400">1. Student Experience</span>
                  <ul className="text-xs text-slate-400 space-y-1 list-disc pl-4">
                    <li>Browse categories (Breakfast, Lunch, Snacks, etc.)</li>
                    <li>Real-time search & dietary filters</li>
                    <li>Dynamic cart with instant total calculation</li>
                    <li>Simulated UPI (GPay/PhonePe/QR) or Cash</li>
                    <li>Unique digital token generation (#CT-xxx)</li>
                  </ul>
                </div>

                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-1.5">
                  <span className="text-xs font-bold text-amber-400">2. Kitchen Management</span>
                  <ul className="text-xs text-slate-400 space-y-1 list-disc pl-4">
                    <li>5-Stage state machine: Placed → Accepted → Preparing → Ready → Completed</li>
                    <li>Audio chimes when orders are ready</li>
                    <li>KPI dashboard (Total, Queue, Revenue)</li>
                    <li>Add/Edit/Delete food items</li>
                    <li>1-click stock availability toggle</li>
                  </ul>
                </div>

                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-1.5">
                  <span className="text-xs font-bold text-blue-400">3. Architecture</span>
                  <ul className="text-xs text-slate-400 space-y-1 list-disc pl-4">
                    <li>Pure client-side persistence via localStorage</li>
                    <li>Live multi-tab synchronization</li>
                    <li>No paid APIs or external dependencies needed</li>
                    <li>Runs seamlessly in VS Code with Live Server</li>
                    <li>Exportable to plain index.html, style.css, app.js</li>
                  </ul>
                </div>
              </div>

              <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-2">
                <h5 className="font-bold text-white text-xs">How to Run Locally in VS Code Live Server:</h5>
                <ol className="text-xs text-slate-400 space-y-1 list-decimal pl-4">
                  <li>Download or copy the 3 files (index.html, style.css, app.js) into a single folder.</li>
                  <li>Open the folder in Visual Studio Code.</li>
                  <li>Right-click <code className="text-orange-400">index.html</code> and click <strong>&quot;Open with Live Server&quot;</strong>.</li>
                  <li>The app will run locally at <code className="text-emerald-400">http://127.0.0.1:5500/index.html</code> with zero setup required!</li>
                </ol>
              </div>
            </div>
          ) : activeFile === 'index.html' ? (
            <pre className="whitespace-pre-wrap leading-relaxed select-all">
              {STANDALONE_HTML}
            </pre>
          ) : activeFile === 'style.css' ? (
            <pre className="whitespace-pre-wrap leading-relaxed select-all">
              {STANDALONE_CSS}
            </pre>
          ) : (
            <pre className="whitespace-pre-wrap leading-relaxed select-all">
              {STANDALONE_JS}
            </pre>
          )}
        </div>
      </div>
    </div>
  );
};

// Standalone clean vanilla files for complete portability:
const STANDALONE_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Smart Canteen – Online Food Ordering System</title>
  <link rel="stylesheet" href="style.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
  <!-- Demo Mode Banner -->
  <div class="demo-ribbon">
    <span>DEMO MODE &bull; SIMULATED PAYMENT &bull; COLLEGE MINI-PROJECT PROTOTYPE</span>
  </div>

  <!-- Header Navigation -->
  <header class="navbar">
    <div class="nav-container">
      <div class="brand">
        <div class="brand-icon">&#127828;</div>
        <div>
          <h2>Smart Canteen</h2>
          <p>Campus Food Ordering</p>
        </div>
      </div>

      <nav class="nav-links">
        <button class="nav-btn active" data-tab="menu">Food Menu</button>
        <button class="nav-btn" data-tab="tracker">Token Tracker</button>
        <button class="nav-btn" data-tab="history">Order History</button>
        <button class="nav-btn admin-btn" data-tab="admin">Admin Kitchen</button>
      </nav>

      <div class="nav-actions">
        <button id="cartBtn" class="cart-btn">
          <span>&#128722; Cart</span>
          <span id="cartCountBadge" class="badge">0</span>
        </button>
        <button id="authBtn" class="auth-btn">Student Login</button>
      </div>
    </div>
  </header>

  <!-- Main Views Container -->
  <main class="main-content">
    <!-- STUDENT MENU VIEW -->
    <section id="viewMenu" class="view-section active">
      <div class="hero-banner">
        <h1>Welcome to Smart Canteen!</h1>
        <p>Order food online, skip cafeteria queues, and collect with digital queue tokens.</p>
      </div>

      <div class="toolbar">
        <input type="text" id="searchInput" placeholder="Search idli, dosa, meals, coffee...">
        <div class="categories" id="categoryTabs">
          <button class="cat-btn active" data-cat="All">All</button>
          <button class="cat-btn" data-cat="Breakfast">Breakfast</button>
          <button class="cat-btn" data-cat="Lunch">Lunch</button>
          <button class="cat-btn" data-cat="Snacks">Snacks</button>
          <button class="cat-btn" data-cat="Beverages">Beverages</button>
          <button class="cat-btn" data-cat="Fast Food">Fast Food</button>
        </div>
      </div>

      <div id="foodGrid" class="food-grid"></div>
    </section>

    <!-- LIVE TOKEN TRACKER VIEW -->
    <section id="viewTracker" class="view-section">
      <div class="tracker-card">
        <div class="token-header">
          <p>DIGITAL QUEUE TOKEN</p>
          <h1 id="tokenDisplayNumber">#CT-101</h1>
          <span id="tokenStatusBadge" class="status-badge">Preparing</span>
        </div>
        <div class="tracker-stepper" id="stepperContainer"></div>
        <div id="orderItemsSummary" class="order-summary-box"></div>
      </div>
    </section>

    <!-- ORDER HISTORY VIEW -->
    <section id="viewHistory" class="view-section">
      <h2>Your Previous Orders</h2>
      <div id="historyList" class="history-list"></div>
    </section>

    <!-- ADMIN CONSOLE VIEW -->
    <section id="viewAdmin" class="view-section">
      <div class="admin-kpis">
        <div class="kpi-card"><span>Total Orders</span><strong id="kpiTotalOrders">0</strong></div>
        <div class="kpi-card"><span>Kitchen Queue</span><strong id="kpiPendingOrders">0</strong></div>
        <div class="kpi-card"><span>Ready for Pickup</span><strong id="kpiReadyOrders">0</strong></div>
        <div class="kpi-card"><span>Total Demo Sales</span><strong id="kpiTotalSales">₹0</strong></div>
      </div>
      <div class="admin-queue">
        <h3>Live Kitchen Orders</h3>
        <div id="adminOrdersGrid" class="admin-grid"></div>
      </div>
    </section>
  </main>

  <script src="app.js"></script>
</body>
</html>`;

const STANDALONE_CSS = `* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
}
body {
  background: #FFFBF7;
  color: #1E293B;
}
.demo-ribbon {
  background: #F59E0B;
  color: #451A03;
  text-align: center;
  font-size: 11px;
  font-weight: 700;
  padding: 6px;
}
.navbar {
  background: #FFFFFF;
  border-bottom: 1px solid #FED7AA;
  position: sticky;
  top: 0;
  z-index: 100;
}
.nav-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 12px 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.brand {
  display: flex;
  align-items: center;
  gap: 10px;
}
.brand-icon {
  background: #F97316;
  color: #FFF;
  width: 36px;
  height: 36px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.nav-links {
  display: flex;
  gap: 8px;
}
.nav-btn {
  background: none;
  border: none;
  padding: 8px 14px;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  color: #64748B;
}
.nav-btn.active {
  background: #FFEDD5;
  color: #EA580C;
}
.admin-btn {
  background: #0F172A;
  color: #FFF;
}
.cart-btn {
  background: #F97316;
  color: #FFF;
  border: none;
  padding: 8px 16px;
  border-radius: 10px;
  font-weight: 700;
  cursor: pointer;
}
.main-content {
  max-width: 1200px;
  margin: 20px auto;
  padding: 0 20px;
}
.view-section {
  display: none;
}
.view-section.active {
  display: block;
}
.hero-banner {
  background: linear-gradient(135deg, #F97316, #F59E0B);
  color: #FFF;
  padding: 30px;
  border-radius: 20px;
  margin-bottom: 24px;
}
.food-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 20px;
  margin-top: 20px;
}
.food-card {
  background: #FFF;
  border-radius: 16px;
  border: 1px solid #E2E8F0;
  overflow: hidden;
  box-shadow: 0 2px 4px rgba(0,0,0,0.04);
}
.food-card img {
  width: 100%;
  height: 180px;
  object-fit: cover;
}
.food-card-body {
  padding: 14px;
}
.food-price {
  font-size: 18px;
  font-weight: 800;
  color: #0F172A;
}
.add-btn {
  background: #F97316;
  color: #FFF;
  border: none;
  padding: 6px 14px;
  border-radius: 8px;
  font-weight: 700;
  cursor: pointer;
}`;

const STANDALONE_JS = `// Smart Canteen – Vanilla JavaScript Core Logic
const MENU_ITEMS = [
  { id: '1', name: 'Steamed Idli (2 Pcs)', price: 20, category: 'Breakfast', prep: 5, inStock: true },
  { id: '2', name: 'Crispy Masala Dosa', price: 40, category: 'Breakfast', prep: 8, inStock: true },
  { id: '3', name: 'Poori Masala (3 Pcs)', price: 35, category: 'Breakfast', prep: 7, inStock: true },
  { id: '4', name: 'South Indian Veg Meals', price: 80, category: 'Lunch', prep: 10, inStock: true },
  { id: '5', name: 'Veg Fried Rice', price: 70, category: 'Lunch', prep: 12, inStock: true },
  { id: '6', name: 'Grilled Veg Club Sandwich', price: 40, category: 'Snacks', prep: 6, inStock: true },
  { id: '7', name: 'Canteen Crispy Veg Burger', price: 60, category: 'Fast Food', prep: 8, inStock: true },
  { id: '8', name: 'Special Masala Chai', price: 10, category: 'Beverages', prep: 3, inStock: true },
  { id: '9', name: 'South Indian Filter Coffee', price: 15, category: 'Beverages', prep: 4, inStock: true },
  { id: '10', name: 'Fresh Fruit Juice', price: 30, category: 'Beverages', prep: 5, inStock: true }
];

let cart = JSON.parse(localStorage.getItem('canteen_cart') || '[]');
let orders = JSON.parse(localStorage.getItem('canteen_orders') || '[]');

function saveCart() {
  localStorage.setItem('canteen_cart', JSON.stringify(cart));
  updateCartBadge();
}

function updateCartBadge() {
  const count = cart.reduce((s, c) => s + c.qty, 0);
  const badge = document.getElementById('cartCountBadge');
  if (badge) badge.innerText = count;
}

function renderMenu(category = 'All', search = '') {
  const grid = document.getElementById('foodGrid');
  if (!grid) return;
  grid.innerHTML = '';

  const filtered = MENU_ITEMS.filter(item => {
    if (category !== 'All' && item.category !== category) return false;
    if (search && !item.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  filtered.forEach(item => {
    const card = document.createElement('div');
    card.className = 'food-card';
    card.innerHTML = \`
      <div style="background:#FED7AA; height:150px; display:flex; align-items:center; justify-content:center; font-size:32px;">&#127858;</div>
      <div class="food-card-body">
        <span style="font-size:11px; color:#64748B;">\${item.category} &bull; \${item.prep}m prep</span>
        <h4 style="font-size:16px; margin:4px 0;">\${item.name}</h4>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px;">
          <span class="food-price">₹\${item.price}</span>
          <button class="add-btn" onclick="addToCart('\${item.id}')">+ Add</button>
        </div>
      </div>
    \`;
    grid.appendChild(card);
  });
}

function addToCart(itemId) {
  const found = MENU_ITEMS.find(i => i.id === itemId);
  if (!found) return;
  const existing = cart.find(c => c.id === itemId);
  if (existing) existing.qty += 1;
  else cart.push({ ...found, qty: 1 });
  saveCart();
  alert(found.name + ' added to cart!');
}

window.addEventListener('DOMContentLoaded', () => {
  renderMenu();
  updateCartBadge();
});`;
