import React from 'react';
import { useCanteen } from '../context/CanteenContext';
import { OrderStatus } from '../types';
import { 
  Ticket, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  ChevronRight, 
  ChefHat, 
  ShoppingBag, 
  Sparkles,
  QrCode,
  ArrowRight,
  RefreshCw,
  BellRing
} from 'lucide-react';

const ORDER_STEPS: { key: OrderStatus; label: string; desc: string }[] = [
  { key: 'placed', label: 'Order Placed', desc: 'Token generated & sent to kitchen' },
  { key: 'accepted', label: 'Order Accepted', desc: 'Kitchen confirmed preparation' },
  { key: 'preparing', label: 'Preparing', desc: 'Chef cooking fresh on stove' },
  { key: 'ready', label: 'Ready for Pickup', desc: 'Collect food at pickup counter' },
  { key: 'completed', label: 'Completed', desc: 'Handed over to student' }
];

export const LiveOrderTracker: React.FC = () => {
  const { 
    currentUser, 
    orders, 
    updateOrderStatus, 
    setActiveTab 
  } = useCanteen();

  // Find the active ongoing order (or the most recent order)
  const userOrders = currentUser?.role === 'admin' 
    ? orders 
    : orders.filter(o => !currentUser || o.userId === currentUser.id);

  const activeOrder = userOrders.find(o => o.status !== 'completed') || userOrders[0];

  if (!activeOrder) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-orange-100 text-orange-500 flex items-center justify-center mx-auto">
          <Ticket className="w-8 h-8" />
        </div>
        <h3 className="text-xl font-bold text-slate-800">No Active Order Found</h3>
        <p className="text-xs text-slate-500 max-w-sm mx-auto">
          You don&apos;t have any active canteen tokens right now. Explore today&apos;s food menu and place an order!
        </p>
        <button
          onClick={() => setActiveTab('menu')}
          className="px-5 py-2.5 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs rounded-xl shadow-md transition-colors inline-flex items-center gap-2"
        >
          <span>Browse Food Menu</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    );
  }

  const currentStepIndex = ORDER_STEPS.findIndex(s => s.key === activeOrder.status);

  // Helper to advance the order for live testing
  const handleSimulateNextStep = () => {
    const nextIndex = currentStepIndex + 1;
    if (nextIndex < ORDER_STEPS.length) {
      updateOrderStatus(activeOrder.id, ORDER_STEPS[nextIndex].key);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Banner Notice */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center shrink-0">
            <Ticket className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Live Digital Order Token
            </h2>
            <p className="text-xs text-slate-500">
              Show this token number at the canteen counter when food is ready
            </p>
          </div>
        </div>

        {/* Quick Testing Helper */}
        {activeOrder.status !== 'completed' && (
          <button
            onClick={handleSimulateNextStep}
            className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors self-start sm:self-center"
            title="Simulate canteen staff moving order to next stage"
          >
            <RefreshCw className="w-3.5 h-3.5 text-amber-600" />
            <span>Simulate Kitchen Next Step</span>
          </button>
        )}
      </div>

      {/* Main Digital Token Card */}
      <div className="bg-white rounded-3xl border-2 border-orange-200 shadow-xl overflow-hidden">
        {/* Token Header Stripe */}
        <div className="bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 p-6 sm:p-8 text-white relative">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-orange-200 block mb-1">
                College Canteen Digital Queue Token
              </span>
              <div className="flex items-baseline gap-3">
                <span className="font-mono text-4xl sm:text-5xl font-black tracking-wider drop-shadow-xs">
                  {activeOrder.tokenNumber}
                </span>
                <span className={`px-2.5 py-1 rounded-full text-xs font-bold border capitalize ${
                  activeOrder.status === 'ready'
                    ? 'bg-emerald-500 text-white border-emerald-400 animate-bounce'
                    : activeOrder.status === 'completed'
                    ? 'bg-slate-800 text-white border-slate-700'
                    : 'bg-white/20 text-white border-white/30'
                }`}>
                  {activeOrder.status === 'ready' ? 'Food Ready for Pickup!' : activeOrder.status}
                </span>
              </div>
            </div>

            {/* QR Code / Barcode Simulation */}
            <div className="bg-white p-2.5 rounded-2xl text-slate-900 flex items-center gap-3 shrink-0 shadow-md">
              <QrCode className="w-14 h-14 text-slate-800" />
              <div className="text-left font-mono text-[11px] leading-tight text-slate-600 hidden sm:block">
                <div className="font-bold text-slate-900">{activeOrder.tokenNumber}</div>
                <div>{activeOrder.userPhone}</div>
                <div className="text-[9px] text-emerald-700 font-bold uppercase">
                  {activeOrder.paymentStatus === 'completed' ? 'PAID ONLINE' : 'PAY CASH'}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Counter & Est Time Row */}
        <div className="bg-amber-50/70 border-b border-orange-100 px-6 py-4 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center shrink-0">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] font-medium">Pickup Counter</span>
              <strong className="text-slate-900 font-semibold">{activeOrder.pickupCounter}</strong>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center shrink-0">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] font-medium">Estimated Time</span>
              <strong className="text-slate-900 font-semibold">
                {activeOrder.status === 'ready' ? 'Ready Now!' : `~${activeOrder.estimatedMinutes} mins`}
              </strong>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center shrink-0">
              <BellRing className="w-4 h-4" />
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] font-medium">Student / Roll</span>
              <strong className="text-slate-900 font-semibold">
                {activeOrder.userName} ({activeOrder.rollNumber || '23CS018'})
              </strong>
            </div>
          </div>
        </div>

        {/* 5-Step Order Status Progress Tracker */}
        <div className="p-6 sm:p-8 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">
              Order Preparation Lifecycle
            </h3>
            <span className="text-xs text-slate-500">
              Step {currentStepIndex + 1} of 5
            </span>
          </div>

          {/* Stepper line */}
          <div className="relative">
            {/* Progress Bar background */}
            <div className="hidden sm:block absolute top-1/2 left-0 right-0 h-1 bg-slate-200 -translate-y-1/2 z-0" />
            
            {/* Active progress bar highlight */}
            <div 
              className="hidden sm:block absolute top-1/2 left-0 h-1 bg-orange-500 -translate-y-1/2 z-0 transition-all duration-500"
              style={{ width: `${(currentStepIndex / (ORDER_STEPS.length - 1)) * 100}%` }}
            />

            <div className="grid grid-cols-1 sm:grid-cols-5 gap-4 relative z-10">
              {ORDER_STEPS.map((step, idx) => {
                const isPassed = idx < currentStepIndex;
                const isCurrent = idx === currentStepIndex;

                return (
                  <div 
                    key={step.key}
                    className="flex sm:flex-col items-center sm:text-center gap-3 sm:gap-2"
                  >
                    <div 
                      className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs transition-all ${
                        isPassed
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : isCurrent
                          ? 'bg-orange-500 text-white ring-4 ring-orange-100 shadow-md scale-110'
                          : 'bg-white text-slate-400 border-2 border-slate-200'
                      }`}
                    >
                      {isPassed ? (
                        <CheckCircle2 className="w-5 h-5" />
                      ) : (
                        <span>0{idx + 1}</span>
                      )}
                    </div>

                    <div className="text-left sm:text-center">
                      <span className={`block text-xs font-bold ${
                        isCurrent ? 'text-orange-600' : isPassed ? 'text-slate-800' : 'text-slate-400'
                      }`}>
                        {step.label}
                      </span>
                      <span className="block text-[10px] text-slate-500 leading-tight">
                        {step.desc}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Current Status Highlight Box */}
          <div className={`p-4 rounded-2xl border flex items-center justify-between ${
            activeOrder.status === 'ready'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
              : 'bg-orange-50/70 border-orange-200 text-orange-950'
          }`}>
            <div className="flex items-center gap-3">
              <ChefHat className={`w-5 h-5 ${activeOrder.status === 'ready' ? 'text-emerald-600' : 'text-orange-500'}`} />
              <div>
                <span className="text-xs font-bold block">
                  {activeOrder.status === 'ready'
                    ? 'Please approach the counter to collect your food!'
                    : activeOrder.status === 'preparing'
                    ? 'Food is on the stove/tawa. Almost ready!'
                    : activeOrder.status === 'accepted'
                    ? 'Kitchen staff accepted your order.'
                    : 'Order placed in digital queue.'}
                </span>
                <span className="text-[11px] opacity-80">
                  Assigned to: {activeOrder.pickupCounter}
                </span>
              </div>
            </div>

            {activeOrder.status === 'ready' && (
              <button
                onClick={() => updateOrderStatus(activeOrder.id, 'completed')}
                className="px-3 py-1.5 bg-emerald-600 text-white text-xs font-bold rounded-xl shadow-xs hover:bg-emerald-700 transition-colors shrink-0"
              >
                I Collected Food
              </button>
            )}
          </div>

          {/* Itemized Order Details */}
          <div className="border-t border-slate-100 pt-5 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Ordered Food Items
            </h4>

            <div className="space-y-2">
              {activeOrder.items.map(({ item, quantity }) => (
                <div key={item.id} className="flex items-center justify-between text-xs py-1 border-b border-slate-50">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                    <span className="font-semibold text-slate-800">{item.name}</span>
                    <span className="text-slate-400">× {quantity}</span>
                  </div>
                  <span className="font-mono font-medium text-slate-700">₹{item.price * quantity}</span>
                </div>
              ))}
            </div>

            <div className="flex justify-between items-center pt-2 text-xs font-bold text-slate-900">
              <span>Total Amount ({activeOrder.paymentMethod === 'upi' ? 'Demo UPI Paid' : 'Cash on Pickup'})</span>
              <span className="font-mono text-sm text-orange-600">₹{activeOrder.total}</span>
            </div>

            {activeOrder.specialInstructions && (
              <div className="text-xs text-slate-500 bg-slate-50 p-2 rounded-lg">
                <strong>Kitchen Note:</strong> &quot;{activeOrder.specialInstructions}&quot;
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
