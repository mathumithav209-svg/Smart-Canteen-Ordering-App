import React from 'react';
import { useCanteen } from '../context/CanteenContext';
import { 
  UtensilsCrossed, 
  ShoppingBag, 
  Ticket, 
  History, 
  ChefHat, 
  User as UserIcon, 
  LogOut, 
  Info,
  Code2
} from 'lucide-react';

interface HeaderProps {
  onOpenCodeModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenCodeModal }) => {
  const { 
    currentUser, 
    activeTab, 
    setActiveTab, 
    cartTotalCount, 
    cartSubtotal,
    setIsAuthModalOpen, 
    setAuthMode, 
    logout,
    orders
  } = useCanteen();

  // Find if there is an active ongoing order
  const activeOrder = orders.find(o => 
    o.status !== 'completed' && 
    (!currentUser || currentUser.role === 'admin' || o.userId === currentUser.id)
  );

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-orange-100 shadow-xs">
      {/* Mini-Project & Demo Mode Notice Ribbon */}
      <div className="bg-amber-500 text-amber-950 px-4 py-1 text-xs font-medium border-b border-amber-600/20">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 truncate">
            <span className="bg-amber-900 text-amber-100 px-1.5 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase">
              Demo Mode
            </span>
            <span className="truncate">
              College Mini-Project Prototype · Simulated UPI & Cash Payments · Sample Canteen Kitchen Data
            </span>
          </div>
          <button
            onClick={onOpenCodeModal}
            className="hidden sm:inline-flex items-center gap-1.5 text-xs text-amber-950 hover:text-white font-semibold underline decoration-amber-950/40 hover:decoration-white transition-colors shrink-0"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Standalone Code (HTML/CSS/JS)</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('menu')}
              className="flex items-center gap-2.5 text-left group focus:outline-hidden"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center text-white shadow-md shadow-orange-500/20 group-hover:scale-105 transition-transform">
                <UtensilsCrossed className="w-5 h-5" />
              </div>
              <div>
                <span className="text-lg font-bold tracking-tight text-slate-900 flex items-center gap-1.5 leading-none">
                  Smart Canteen
                  <span className="text-[11px] font-medium text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-full border border-emerald-200">
                    Live
                  </span>
                </span>
                <span className="text-xs text-slate-500 font-medium">Campus Food Ordering</span>
              </div>
            </button>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 sm:gap-2">
            <button
              onClick={() => setActiveTab('menu')}
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 ${
                activeTab === 'menu'
                  ? 'bg-orange-50 text-orange-600'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <span>Food Menu</span>
            </button>

            <button
              onClick={() => setActiveTab('tracker')}
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 relative ${
                activeTab === 'tracker'
                  ? 'bg-orange-50 text-orange-600'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Ticket className="w-4 h-4" />
              <span>Token Tracker</span>
              {activeOrder && (
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="Active order in progress" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('orders')}
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 ${
                activeTab === 'orders'
                  ? 'bg-orange-50 text-orange-600'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <History className="w-4 h-4" />
              <span>Order History</span>
            </button>

            <button
              onClick={() => setActiveTab('admin')}
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 ${
                activeTab === 'admin'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <ChefHat className="w-4 h-4 text-amber-400" />
              <span>Admin Kitchen</span>
            </button>
          </nav>

          {/* Zone 3: Primary Actions (Cart + User) */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Cart Button */}
            <button
              onClick={() => setActiveTab('cart')}
              className={`relative px-3.5 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-2 border ${
                activeTab === 'cart'
                  ? 'bg-orange-500 text-white border-orange-500 shadow-md shadow-orange-500/25'
                  : 'bg-white text-slate-800 border-slate-200 hover:border-orange-300 hover:bg-orange-50/50'
              }`}
              aria-label="View shopping cart"
            >
              <div className="relative">
                <ShoppingBag className="w-4 h-4" />
                {cartTotalCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-emerald-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                    {cartTotalCount}
                  </span>
                )}
              </div>
              <span className="hidden sm:inline">Cart</span>
              {cartSubtotal > 0 && (
                <span className="font-mono text-xs font-bold pl-1 border-l border-slate-200/60">
                  ₹{cartSubtotal}
                </span>
              )}
            </button>

            {/* User Profile / Login */}
            {currentUser ? (
              <div className="flex items-center gap-2">
                <div className="hidden lg:flex flex-col text-right">
                  <span className="text-xs font-bold text-slate-800 truncate max-w-[130px]">
                    {currentUser.name}
                  </span>
                  <span className="text-[10px] font-medium text-slate-500 capitalize">
                    {currentUser.role === 'admin' ? 'Canteen Admin' : `Student (${currentUser.rollNumber || 'ID'})`}
                  </span>
                </div>
                <button
                  onClick={logout}
                  className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  setAuthMode('login');
                  setIsAuthModalOpen(true);
                }}
                className="px-3.5 py-2 text-xs font-semibold text-orange-700 bg-orange-100/70 hover:bg-orange-100 rounded-xl transition-colors flex items-center gap-1.5"
              >
                <UserIcon className="w-3.5 h-3.5" />
                <span>Login</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation bar for smaller screens */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-slate-100 text-xs font-medium">
          <button
            onClick={() => setActiveTab('menu')}
            className={`py-1 px-2 rounded-md ${activeTab === 'menu' ? 'text-orange-600 font-bold' : 'text-slate-600'}`}
          >
            Menu
          </button>
          <button
            onClick={() => setActiveTab('tracker')}
            className={`py-1 px-2 rounded-md flex items-center gap-1 ${activeTab === 'tracker' ? 'text-orange-600 font-bold' : 'text-slate-600'}`}
          >
            Token
            {activeOrder && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />}
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`py-1 px-2 rounded-md ${activeTab === 'orders' ? 'text-orange-600 font-bold' : 'text-slate-600'}`}
          >
            Orders
          </button>
          <button
            onClick={() => setActiveTab('admin')}
            className={`py-1 px-2 rounded-md flex items-center gap-1 ${activeTab === 'admin' ? 'text-orange-600 font-bold' : 'text-slate-600'}`}
          >
            <ChefHat className="w-3.5 h-3.5 text-amber-500" />
            Kitchen
          </button>
          <button
            onClick={onOpenCodeModal}
            className="py-1 px-2 rounded-md text-slate-500 flex items-center gap-1"
          >
            <Info className="w-3.5 h-3.5" />
            Code
          </button>
        </div>
      </div>
    </header>
  );
};
