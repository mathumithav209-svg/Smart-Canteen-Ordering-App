import React, { useState } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { FoodItem, FoodCategory, OrderStatus } from '../types';
import { 
  ChefHat, 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Plus, 
  Trash2, 
  Edit3, 
  ToggleLeft, 
  ToggleRight, 
  Search, 
  ShoppingBag, 
  RefreshCw, 
  X, 
  IndianRupee,
  Utensils,
  Sparkles,
  ArrowRight
} from 'lucide-react';

const CATEGORIES: Exclude<FoodCategory, 'All'>[] = ['Breakfast', 'Lunch', 'Snacks', 'Beverages', 'Fast Food'];

export const AdminDashboard: React.FC = () => {
  const { 
    menu, 
    orders, 
    updateOrderStatus, 
    addMenuItem, 
    updateMenuItem, 
    deleteMenuItem, 
    toggleItemAvailability, 
    resetDefaultMenu, 
    generateSampleOrder,
    quickLoginAs,
    currentUser
  } = useCanteen();

  // Active sub-tab in Admin
  const [adminView, setAdminView] = useState<'orders' | 'menu'>('orders');
  const [orderFilter, setOrderFilter] = useState<'all' | 'pending' | 'ready' | 'completed'>('pending');

  // Menu search & modal state
  const [menuSearch, setMenuSearch] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<FoodItem | null>(null);

  // Form states for Add/Edit
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState<Exclude<FoodCategory, 'All'>>('Breakfast');
  const [formPrice, setFormPrice] = useState<number>(30);
  const [formPrepTime, setFormPrepTime] = useState<number>(8);
  const [formDesc, setFormDesc] = useState('');
  const [formImage, setFormImage] = useState('/src/assets/images/south_indian_breakfast_1793703442700.jpg');
  const [formIsVeg, setFormIsVeg] = useState(true);
  const [formIsSpecial, setFormIsSpecial] = useState(false);

  // Metrics calculation
  const totalOrdersCount = orders.length;
  const pendingOrdersCount = orders.filter(o => o.status === 'placed' || o.status === 'accepted' || o.status === 'preparing').length;
  const readyOrdersCount = orders.filter(o => o.status === 'ready').length;
  const completedOrdersCount = orders.filter(o => o.status === 'completed').length;
  const totalSalesRevenue = orders.reduce((sum, o) => sum + o.total, 0);

  // Filtered orders
  const filteredOrders = orders.filter(o => {
    if (orderFilter === 'pending') return o.status === 'placed' || o.status === 'accepted' || o.status === 'preparing';
    if (orderFilter === 'ready') return o.status === 'ready';
    if (orderFilter === 'completed') return o.status === 'completed';
    return true;
  });

  // Filtered menu items
  const filteredMenu = menu.filter(item => {
    if (!menuSearch) return true;
    const q = menuSearch.toLowerCase();
    return item.name.toLowerCase().includes(q) || item.category.toLowerCase().includes(q);
  });

  const handleOpenAddModal = () => {
    setEditingItem(null);
    setFormName('');
    setFormCategory('Breakfast');
    setFormPrice(30);
    setFormPrepTime(8);
    setFormDesc('');
    setFormImage('/src/assets/images/south_indian_breakfast_1793703442700.jpg');
    setFormIsVeg(true);
    setFormIsSpecial(false);
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (item: FoodItem) => {
    setEditingItem(item);
    setFormName(item.name);
    setFormCategory(item.category);
    setFormPrice(item.price);
    setFormPrepTime(item.prepTimeMinutes);
    setFormDesc(item.description);
    setFormImage(item.image);
    setFormIsVeg(item.isVeg);
    setFormIsSpecial(item.isSpecial || false);
    setIsAddModalOpen(true);
  };

  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    if (editingItem) {
      updateMenuItem({
        ...editingItem,
        name: formName.trim(),
        category: formCategory,
        price: Number(formPrice),
        prepTimeMinutes: Number(formPrepTime),
        description: formDesc.trim() || 'Freshly prepared at the canteen.',
        image: formImage,
        isVeg: formIsVeg,
        isSpecial: formIsSpecial
      });
    } else {
      addMenuItem({
        name: formName.trim(),
        category: formCategory,
        price: Number(formPrice),
        prepTimeMinutes: Number(formPrepTime),
        description: formDesc.trim() || 'Freshly prepared at the canteen.',
        image: formImage,
        available: true,
        isVeg: formIsVeg,
        isSpecial: formIsSpecial,
        rating: 4.8
      });
    }

    setIsAddModalOpen(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Banner / Role Status */}
      <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <ChefHat className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold">Canteen Kitchen & Admin Console</h1>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-amber-400 text-slate-950 px-2 py-0.5 rounded">
                Manager View
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Live token queue control, order state dispatch, and daily menu price management
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={generateSampleOrder}
            className="px-3 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl transition-all shadow-md flex items-center gap-1.5"
            title="Create an incoming demo order to test live status progression"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Simulate Student Order</span>
          </button>

          <button
            onClick={() => quickLoginAs('student')}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl transition-colors border border-slate-700"
          >
            Switch to Student View
          </button>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Total Orders</span>
            <ShoppingBag className="w-4 h-4 text-orange-500" />
          </div>
          <div className="font-mono text-2xl sm:text-3xl font-extrabold text-slate-900">
            {totalOrdersCount}
          </div>
          <span className="text-[11px] text-slate-400 block mt-1">Campus canteen tokens</span>
        </div>

        {/* KPI 2 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Kitchen Queue</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="font-mono text-2xl sm:text-3xl font-extrabold text-amber-600">
            {pendingOrdersCount}
          </div>
          <span className="text-[11px] text-slate-400 block mt-1">Placed or currently cooking</span>
        </div>

        {/* KPI 3 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Ready at Counter</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="font-mono text-2xl sm:text-3xl font-extrabold text-emerald-600">
            {readyOrdersCount}
          </div>
          <span className="text-[11px] text-slate-400 block mt-1">Awaiting student pickup</span>
        </div>

        {/* KPI 4 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Demo Sales</span>
            <TrendingUp className="w-4 h-4 text-blue-500" />
          </div>
          <div className="font-mono text-2xl sm:text-3xl font-extrabold text-slate-900">
            ₹{totalSalesRevenue}
          </div>
          <span className="text-[11px] text-slate-400 block mt-1">{completedOrdersCount} collected orders</span>
        </div>
      </div>

      {/* Main Admin Tab Switcher: Orders Queue vs. Food Menu */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setAdminView('orders')}
            className={`px-4 py-2 text-sm font-bold rounded-xl transition-all ${
              adminView === 'orders'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Live Kitchen Orders ({orders.length})
          </button>
          <button
            onClick={() => setAdminView('menu')}
            className={`px-4 py-2 text-sm font-bold rounded-xl transition-all ${
              adminView === 'menu'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Manage Food Menu ({menu.length})
          </button>
        </div>

        {adminView === 'menu' && (
          <div className="flex items-center gap-2">
            <button
              onClick={resetDefaultMenu}
              className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg flex items-center gap-1 font-medium"
              title="Reset all menu items to original state"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Reset Menu</span>
            </button>
            <button
              onClick={handleOpenAddModal}
              className="px-3 py-1.5 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-lg flex items-center gap-1 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Food Item</span>
            </button>
          </div>
        )}
      </div>

      {/* VIEW 1: LIVE ORDERS QUEUE */}
      {adminView === 'orders' && (
        <div className="space-y-4">
          {/* Sub-filter tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <button
              onClick={() => setOrderFilter('pending')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                orderFilter === 'pending' ? 'bg-orange-500 text-white' : 'bg-white text-slate-600 border border-slate-200'
              }`}
            >
              Pending / Cooking ({pendingOrdersCount})
            </button>
            <button
              onClick={() => setOrderFilter('ready')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                orderFilter === 'ready' ? 'bg-emerald-600 text-white' : 'bg-white text-slate-600 border border-slate-200'
              }`}
            >
              Ready for Pickup ({readyOrdersCount})
            </button>
            <button
              onClick={() => setOrderFilter('completed')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                orderFilter === 'completed' ? 'bg-slate-800 text-white' : 'bg-white text-slate-600 border border-slate-200'
              }`}
            >
              Completed / Handed Over ({completedOrdersCount})
            </button>
            <button
              onClick={() => setOrderFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                orderFilter === 'all' ? 'bg-slate-900 text-white' : 'bg-white text-slate-600 border border-slate-200'
              }`}
            >
              All Orders ({orders.length})
            </button>
          </div>

          {filteredOrders.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500 text-xs">
              No orders found under &quot;{orderFilter}&quot; filter.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredOrders.map(order => {
                return (
                  <div
                    key={order.id}
                    className={`bg-white rounded-2xl border p-4 shadow-2xs space-y-3 flex flex-col justify-between ${
                      order.status === 'ready'
                        ? 'border-emerald-300 ring-2 ring-emerald-500/10'
                        : order.status === 'preparing'
                        ? 'border-orange-300'
                        : 'border-slate-200'
                    }`}
                  >
                    <div>
                      {/* Order Header */}
                      <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-base font-black text-orange-600 bg-orange-50 px-2 py-0.5 rounded border border-orange-200">
                            #{order.tokenNumber}
                          </span>
                          <span className="text-[11px] font-bold text-slate-800">
                            {order.userName.split(' ')[0]}
                          </span>
                        </div>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          order.status === 'ready'
                            ? 'bg-emerald-100 text-emerald-800'
                            : order.status === 'preparing'
                            ? 'bg-orange-100 text-orange-800'
                            : order.status === 'completed'
                            ? 'bg-slate-100 text-slate-700'
                            : 'bg-blue-100 text-blue-800'
                        }`}>
                          {order.status}
                        </span>
                      </div>

                      {/* Info lines */}
                      <div className="pt-2 text-[11px] text-slate-500 space-y-1">
                        <div className="flex justify-between">
                          <span>Phone: <strong>{order.userPhone}</strong></span>
                          <span>Time: {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Counter: <strong>{order.pickupCounter.split(' ')[0]}</strong></span>
                          <span className="font-semibold text-slate-700">
                            {order.paymentMethod === 'upi' ? 'UPI Paid' : 'Cash on Pickup'}
                          </span>
                        </div>
                      </div>

                      {/* Items Ordered */}
                      <div className="mt-3 bg-slate-50 rounded-xl p-2.5 space-y-1 text-xs">
                        {order.items.map(({ item, quantity }) => (
                          <div key={item.id} className="flex justify-between">
                            <span className="text-slate-800 font-medium">
                              {quantity}× {item.name}
                            </span>
                            <span className="font-mono text-slate-500">
                              ₹{item.price * quantity}
                            </span>
                          </div>
                        ))}

                        {order.specialInstructions && (
                          <div className="text-[10px] text-amber-900 bg-amber-50 p-1 rounded font-medium mt-1">
                            Note: {order.specialInstructions}
                          </div>
                        )}

                        <div className="pt-1.5 border-t border-slate-200/80 flex justify-between font-bold text-xs text-slate-900">
                          <span>Total Amount</span>
                          <span className="font-mono text-orange-600">₹{order.total}</span>
                        </div>
                      </div>
                    </div>

                    {/* Order Action Buttons */}
                    <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                      {order.status === 'placed' && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'accepted')}
                          className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors"
                        >
                          Accept Order
                        </button>
                      )}

                      {order.status === 'accepted' && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'preparing')}
                          className="w-full py-2 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-xl transition-colors"
                        >
                          Start Cooking
                        </button>
                      )}

                      {order.status === 'preparing' && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'ready')}
                          className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Mark Ready for Pickup</span>
                        </button>
                      )}

                      {order.status === 'ready' && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'completed')}
                          className="w-full py-2 bg-slate-800 hover:bg-black text-white text-xs font-bold rounded-xl transition-colors"
                        >
                          Mark Handed Over (Done)
                        </button>
                      )}

                      {order.status === 'completed' && (
                        <div className="w-full text-center text-xs font-medium text-slate-400 py-1">
                          ✓ Order Completed
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* VIEW 2: FOOD MENU MANAGEMENT */}
      {adminView === 'menu' && (
        <div className="space-y-4">
          {/* Menu Search */}
          <div className="flex items-center justify-between gap-4">
            <div className="relative max-w-sm w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={menuSearch}
                onChange={e => setMenuSearch(e.target.value)}
                placeholder="Search food item to edit or toggle stock..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:border-orange-500"
              />
            </div>
            <span className="text-xs text-slate-500">
              Total items: <strong className="font-mono text-slate-800">{filteredMenu.length}</strong>
            </span>
          </div>

          {/* Menu Table / Cards */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
                  <tr>
                    <th className="py-3 px-4">Food Item</th>
                    <th className="py-3 px-3">Category</th>
                    <th className="py-3 px-3">Price</th>
                    <th className="py-3 px-3">Prep Time</th>
                    <th className="py-3 px-3">Stock Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredMenu.map(item => (
                    <tr key={item.id} className="hover:bg-orange-50/30 transition-colors">
                      <td className="py-3 px-4 flex items-center gap-3">
                        <img
                          src={item.image}
                          alt={item.name}
                          referrerPolicy="no-referrer"
                          className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0"
                          onError={e => {
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                        <div>
                          <strong className="text-slate-900 block font-semibold">{item.name}</strong>
                          <span className="text-[11px] text-slate-400 line-clamp-1 max-w-xs">{item.description}</span>
                        </div>
                      </td>

                      <td className="py-3 px-3 text-slate-600 font-medium">
                        {item.category}
                      </td>

                      <td className="py-3 px-3 font-mono font-bold text-slate-900">
                        ₹{item.price}
                      </td>

                      <td className="py-3 px-3 text-slate-600">
                        {item.prepTimeMinutes} mins
                      </td>

                      <td className="py-3 px-3">
                        <button
                          onClick={() => toggleItemAvailability(item.id)}
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full font-bold text-[11px] transition-colors ${
                            item.available
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                              : 'bg-red-50 text-red-700 border border-red-200 hover:bg-red-100'
                          }`}
                          title="Click to toggle availability"
                        >
                          <span className={`w-2 h-2 rounded-full ${item.available ? 'bg-emerald-600' : 'bg-red-600'}`} />
                          <span>{item.available ? 'In Stock' : 'Out of Stock'}</span>
                        </button>
                      </td>

                      <td className="py-3 px-4 text-right space-x-2">
                        <button
                          onClick={() => handleOpenEditModal(item)}
                          className="p-1 text-slate-400 hover:text-orange-600 rounded"
                          title="Edit Item"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Are you sure you want to delete "${item.name}" from canteen menu?`)) {
                              deleteMenuItem(item.id);
                            }
                          }}
                          className="p-1 text-slate-400 hover:text-red-600 rounded"
                          title="Delete Item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Food Item Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-orange-100 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">
                {editingItem ? 'Edit Canteen Food Item' : 'Add New Food Item'}
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveItem} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Food Name *</label>
                <input
                  type="text"
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  placeholder="e.g. Paneer Roll"
                  required
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Category</label>
                  <select
                    value={formCategory}
                    onChange={e => setFormCategory(e.target.value as Exclude<FoodCategory, 'All'>)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white"
                  >
                    {CATEGORIES.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Price (₹) *</label>
                  <input
                    type="number"
                    value={formPrice}
                    onChange={e => setFormPrice(Number(e.target.value))}
                    min={5}
                    max={500}
                    required
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Prep Time (Mins)</label>
                  <input
                    type="number"
                    value={formPrepTime}
                    onChange={e => setFormPrepTime(Number(e.target.value))}
                    min={1}
                    max={60}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>

                <div className="flex items-center gap-4 pt-4">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formIsSpecial}
                      onChange={e => setFormIsSpecial(e.target.checked)}
                      className="rounded text-orange-500"
                    />
                    <span className="font-semibold text-slate-700">Chef Special</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Description</label>
                <textarea
                  value={formDesc}
                  onChange={e => setFormDesc(e.target.value)}
                  rows={2}
                  placeholder="Ingredients, accompaniments, or serving notes"
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-semibold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-xl shadow-xs"
                >
                  {editingItem ? 'Save Changes' : 'Add to Menu'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
