import React from 'react';
import { useCanteen } from '../context/CanteenContext';
import { 
  History, 
  Ticket, 
  Calendar, 
  ChevronRight, 
  CheckCircle2, 
  Clock, 
  ArrowRight,
  Repeat
} from 'lucide-react';

export const OrderHistoryView: React.FC = () => {
  const { 
    currentUser, 
    orders, 
    addToCart, 
    setActiveTab 
  } = useCanteen();

  // Filter orders for the current user
  const userOrders = currentUser?.role === 'admin' 
    ? orders 
    : orders.filter(o => !currentUser || o.userId === currentUser.id);

  const handleReorder = (order: typeof orders[0]) => {
    order.items.forEach(({ item, quantity }) => {
      addToCart(item, quantity);
    });
    setActiveTab('cart');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center">
            <History className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">Your Order History</h2>
            <p className="text-xs text-slate-500">
              Review your previous campus orders and digital tokens
            </p>
          </div>
        </div>

        <button
          onClick={() => setActiveTab('menu')}
          className="text-xs font-semibold text-orange-600 hover:text-orange-700 flex items-center gap-1"
        >
          <span>Order Fresh Food</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {userOrders.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <History className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-slate-800">No Past Orders Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Once you place food orders online, your digital tokens and receipts will be archived here.
          </p>
          <button
            onClick={() => setActiveTab('menu')}
            className="px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-xl transition-colors"
          >
            Go to Food Menu
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {userOrders.map(order => {
            const dateStr = new Date(order.createdAt).toLocaleDateString('en-IN', {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            });

            return (
              <div
                key={order.id}
                className="bg-white rounded-2xl border border-slate-200/90 hover:border-orange-200 p-5 shadow-2xs space-y-4 transition-all"
              >
                {/* Header row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-base font-black text-orange-600 bg-orange-50 px-2.5 py-1 rounded-lg border border-orange-200">
                      #{order.tokenNumber}
                    </span>
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        {order.pickupCounter}
                      </span>
                      <span className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {dateStr}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold capitalize ${
                      order.status === 'completed'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : order.status === 'ready'
                        ? 'bg-amber-100 text-amber-800 border border-amber-300'
                        : 'bg-blue-50 text-blue-700 border border-blue-200'
                    }`}>
                      {order.status === 'completed' ? 'Collected' : order.status}
                    </span>

                    <span className="text-xs font-mono font-bold text-slate-900 ml-2">
                      ₹{order.total}
                    </span>
                  </div>
                </div>

                {/* Items preview */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600">
                  {order.items.map(({ item, quantity }) => (
                    <div key={item.id} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 shrink-0" />
                      <span className="truncate">{item.name}</span>
                      <span className="text-slate-400 shrink-0 font-mono">× {quantity}</span>
                    </div>
                  ))}
                </div>

                {/* Footer with actions */}
                <div className="pt-2 flex items-center justify-between text-xs">
                  <span className="text-[11px] text-slate-400">
                    Payment: <strong className="text-slate-700">{order.paymentMethod === 'upi' ? 'Simulated UPI' : 'Cash at Counter'}</strong> ({order.paymentStatus})
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleReorder(order)}
                      className="px-3 py-1.5 bg-orange-50 hover:bg-orange-100 text-orange-700 font-semibold rounded-lg transition-colors flex items-center gap-1.5 text-xs"
                    >
                      <Repeat className="w-3.5 h-3.5" />
                      <span>Reorder Items</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('tracker')}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg transition-colors flex items-center gap-1 text-xs"
                    >
                      <span>View Token</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
