import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, FoodItem, CartItem, Order, OrderStatus, CanteenNotification } from '../types';
import { INITIAL_FOOD_MENU } from '../data/initialMenu';

interface CanteenContextType {
  currentUser: User | null;
  allUsers: User[];
  menu: FoodItem[];
  cart: CartItem[];
  orders: Order[];
  notifications: CanteenNotification[];
  activeTab: 'menu' | 'cart' | 'tracker' | 'orders' | 'admin';
  setActiveTab: (tab: 'menu' | 'cart' | 'tracker' | 'orders' | 'admin') => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  authMode: 'login' | 'register';
  setAuthMode: (mode: 'login' | 'register') => void;
  loginRolePreference: 'student' | 'admin';
  setLoginRolePreference: (role: 'student' | 'admin') => void;

  // Actions
  login: (email: string, pass: string, role?: 'student' | 'admin') => { success: boolean; message: string };
  register: (name: string, email: string, phone: string, pass: string, rollNumber?: string) => { success: boolean; message: string };
  quickLoginAs: (role: 'student' | 'admin') => void;
  logout: () => void;

  addToCart: (item: FoodItem, quantity?: number) => void;
  removeFromCart: (itemId: string) => void;
  updateCartQuantity: (itemId: string, delta: number) => void;
  clearCart: () => void;

  placeOrder: (paymentMethod: 'cash' | 'upi', specialInstructions?: string) => Order;
  updateOrderStatus: (orderId: string, newStatus: OrderStatus) => void;

  // Admin menu management
  addMenuItem: (item: Omit<FoodItem, 'id'>) => void;
  updateMenuItem: (item: FoodItem) => void;
  deleteMenuItem: (itemId: string) => void;
  toggleItemAvailability: (itemId: string) => void;
  resetDefaultMenu: () => void;
  generateSampleOrder: () => void;

  dismissNotification: (id: string) => void;
  cartTotalCount: number;
  cartSubtotal: number;
}

const CanteenContext = createContext<CanteenContextType | undefined>(undefined);

// Web Audio sound synthesizer for realistic feedback
function playCanteenChime(type: 'placed' | 'ready' | 'ping') {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === 'ready') {
      // 3 ascending happy notes for food ready
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
      osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.12); // E5
      osc.frequency.setValueAtTime(783.99, ctx.currentTime + 0.24); // G5
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.6);
    } else if (type === 'placed') {
      // 2 gentle confirmation chords
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      osc.frequency.setValueAtTime(554.37, ctx.currentTime + 0.1);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.4);
    } else {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.2);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.2);
    }
  } catch {
    // Ignore audio failures if browser blocks autoplay
  }
}

// Initial demo users
const DEFAULT_STUDENT: User = {
  id: 'usr-student-01',
  name: 'Arun Kumar',
  email: 'student@college.edu',
  phone: '9845012345',
  role: 'student',
  rollNumber: '21CS042'
};

const DEFAULT_ADMIN: User = {
  id: 'usr-admin-01',
  name: 'Rajan (Canteen Manager)',
  email: 'admin@canteen.edu',
  phone: '9443055678',
  role: 'admin'
};

// Initial realistic orders
const INITIAL_SAMPLE_ORDERS: Order[] = [
  {
    id: 'ord-101',
    tokenNumber: 'CT-101',
    userId: 'usr-student-01',
    userName: 'Arun Kumar',
    userPhone: '9845012345',
    rollNumber: '21CS042',
    items: [
      {
        item: INITIAL_FOOD_MENU[1], // Crispy Masala Dosa
        quantity: 1
      },
      {
        item: INITIAL_FOOD_MENU[8], // Filter Coffee
        quantity: 1
      }
    ],
    subtotal: 55,
    convenienceFee: 0,
    total: 55,
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    status: 'preparing',
    pickupCounter: 'Counter #1 (Snacks & Hot Beverages)',
    createdAt: new Date(Date.now() - 6 * 60 * 1000).toISOString(),
    estimatedMinutes: 10,
    specialInstructions: 'Coffee extra hot, less sugar please.',
    history: [
      { status: 'placed', timestamp: new Date(Date.now() - 6 * 60 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), label: 'Order Confirmed Online' },
      { status: 'accepted', timestamp: new Date(Date.now() - 5 * 60 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), label: 'Kitchen Master Accepted' },
      { status: 'preparing', timestamp: new Date(Date.now() - 3 * 60 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), label: 'Dosa on Tawa & Coffee Brewed' }
    ]
  },
  {
    id: 'ord-100',
    tokenNumber: 'CT-100',
    userId: 'usr-student-01',
    userName: 'Arun Kumar',
    userPhone: '9845012345',
    rollNumber: '21CS042',
    items: [
      {
        item: INITIAL_FOOD_MENU[3], // Veg Meals
        quantity: 1
      }
    ],
    subtotal: 80,
    convenienceFee: 0,
    total: 80,
    paymentMethod: 'cash',
    paymentStatus: 'completed',
    status: 'completed',
    pickupCounter: 'Counter #2 (Thali & Meals)',
    createdAt: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
    estimatedMinutes: 12,
    history: [
      { status: 'placed', timestamp: '12:15 PM', label: 'Order Placed' },
      { status: 'accepted', timestamp: '12:17 PM', label: 'Order Accepted' },
      { status: 'preparing', timestamp: '12:20 PM', label: 'Meals Prepared' },
      { status: 'ready', timestamp: '12:26 PM', label: 'Ready at Counter 2' },
      { status: 'completed', timestamp: '12:30 PM', label: 'Collected by Student' }
    ]
  }
];

export const CanteenProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation & UI state
  const [activeTab, setActiveTab] = useState<'menu' | 'cart' | 'tracker' | 'orders' | 'admin'>('menu');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [loginRolePreference, setLoginRolePreference] = useState<'student' | 'admin'>('student');

  // Stored state
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('smart_canteen_user');
      return saved ? JSON.parse(saved) : DEFAULT_STUDENT;
    } catch {
      return DEFAULT_STUDENT;
    }
  });

  const [allUsers, setAllUsers] = useState<User[]>(() => {
    try {
      const saved = localStorage.getItem('smart_canteen_registered_users');
      return saved ? JSON.parse(saved) : [DEFAULT_STUDENT, DEFAULT_ADMIN];
    } catch {
      return [DEFAULT_STUDENT, DEFAULT_ADMIN];
    }
  });

  const [menu, setMenu] = useState<FoodItem[]>(() => {
    try {
      const saved = localStorage.getItem('smart_canteen_menu');
      return saved ? JSON.parse(saved) : INITIAL_FOOD_MENU;
    } catch {
      return INITIAL_FOOD_MENU;
    }
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('smart_canteen_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('smart_canteen_orders');
      return saved ? JSON.parse(saved) : INITIAL_SAMPLE_ORDERS;
    } catch {
      return INITIAL_SAMPLE_ORDERS;
    }
  });

  const [notifications, setNotifications] = useState<CanteenNotification[]>([
    {
      id: 'notif-welcome',
      title: 'Smart Canteen Online',
      message: 'Skip the crowd! Place orders online and collect with digital token.',
      time: 'Just now',
      type: 'info'
    }
  ]);

  // Sync state to LocalStorage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('smart_canteen_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('smart_canteen_user');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('smart_canteen_registered_users', JSON.stringify(allUsers));
  }, [allUsers]);

  useEffect(() => {
    localStorage.setItem('smart_canteen_menu', JSON.stringify(menu));
  }, [menu]);

  useEffect(() => {
    localStorage.setItem('smart_canteen_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('smart_canteen_orders', JSON.stringify(orders));
  }, [orders]);

  // Listen to cross-tab storage changes (if student & admin are tested simultaneously)
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'smart_canteen_orders' && e.newValue) {
        try {
          const updatedOrders = JSON.parse(e.newValue);
          setOrders(updatedOrders);
        } catch {
          // ignore parse error
        }
      }
      if (e.key === 'smart_canteen_menu' && e.newValue) {
        try {
          setMenu(JSON.parse(e.newValue));
        } catch {
          // ignore parse error
        }
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  // Cart calculations
  const cartTotalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cart.reduce((sum, item) => sum + item.item.price * item.quantity, 0);

  // Authentication handlers
  const login = (email: string, pass: string, role?: 'student' | 'admin') => {
    const targetRole = role || loginRolePreference;

    if (targetRole === 'admin') {
      if ((email === 'admin@canteen.edu' || email === 'admin') && (pass === 'admin123' || pass === 'admin')) {
        setCurrentUser(DEFAULT_ADMIN);
        setIsAuthModalOpen(false);
        setActiveTab('admin');
        pushNotification('Admin Access Granted', 'Logged in as Canteen Manager.', 'info');
        return { success: true, message: 'Welcome to Admin Kitchen Console!' };
      }
      // Check if registered user is admin
      const found = allUsers.find(u => u.email.toLowerCase() === email.toLowerCase() && u.role === 'admin');
      if (found) {
        setCurrentUser(found);
        setIsAuthModalOpen(false);
        setActiveTab('admin');
        return { success: true, message: `Welcome back, ${found.name}!` };
      }
      return { success: false, message: 'Invalid Admin credentials. Try admin@canteen.edu / admin123' };
    }

    // Student Login
    const found = allUsers.find(u => u.email.toLowerCase() === email.toLowerCase() && u.role === 'student');
    if (found || (email === 'student@college.edu' && (pass === 'student123' || pass === 'student'))) {
      const studentUser = found || DEFAULT_STUDENT;
      setCurrentUser(studentUser);
      setIsAuthModalOpen(false);
      if (activeTab === 'admin') setActiveTab('menu');
      pushNotification('Login Successful', `Welcome back, ${studentUser.name}!`, 'info');
      return { success: true, message: `Welcome back, ${studentUser.name}!` };
    }

    return { success: false, message: 'Student account not found. Try student@college.edu or register a new account.' };
  };

  const register = (name: string, email: string, phone: string, _pass: string, rollNumber?: string) => {
    const existing = allUsers.some(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      return { success: false, message: 'An account with this email already exists.' };
    }

    const newUser: User = {
      id: `usr-${Date.now()}`,
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      role: 'student',
      rollNumber: rollNumber?.trim() || `24CS${Math.floor(100 + Math.random() * 900)}`
    };

    setAllUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
    setIsAuthModalOpen(false);
    pushNotification('Registration Complete', `Welcome to Smart Canteen, ${newUser.name}!`, 'info');
    return { success: true, message: 'Account created successfully!' };
  };

  const quickLoginAs = (role: 'student' | 'admin') => {
    if (role === 'admin') {
      setCurrentUser(DEFAULT_ADMIN);
      setActiveTab('admin');
      pushNotification('Admin Mode Active', 'Managing live canteen kitchen & menu.', 'info');
    } else {
      setCurrentUser(DEFAULT_STUDENT);
      if (activeTab === 'admin') setActiveTab('menu');
      pushNotification('Student Mode Active', 'Browsing canteen food menu.', 'info');
    }
    setIsAuthModalOpen(false);
  };

  const logout = () => {
    setCurrentUser(null);
    setActiveTab('menu');
    pushNotification('Logged Out', 'You have been signed out.', 'info');
  };

  // Cart operations
  const addToCart = (item: FoodItem, quantity: number = 1) => {
    if (!item.available) {
      alert(`${item.name} is currently out of stock.`);
      return;
    }
    playCanteenChime('ping');
    setCart(prev => {
      const idx = prev.findIndex(ci => ci.item.id === item.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = { ...copy[idx], quantity: copy[idx].quantity + quantity };
        return copy;
      }
      return [...prev, { item, quantity }];
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart(prev => prev.filter(ci => ci.item.id !== itemId));
  };

  const updateCartQuantity = (itemId: string, delta: number) => {
    setCart(prev => {
      return prev.map(ci => {
        if (ci.item.id === itemId) {
          const newQty = ci.quantity + delta;
          return newQty > 0 ? { ...ci, quantity: newQty } : null;
        }
        return ci;
      }).filter(Boolean) as CartItem[];
    });
  };

  const clearCart = () => {
    setCart([]);
  };

  // Notifications helper
  const pushNotification = (title: string, message: string, type: 'order_status' | 'order_placed' | 'info', orderId?: string, tokenNumber?: string) => {
    const newNotif: CanteenNotification = {
      id: `notif-${Date.now()}-${Math.random()}`,
      title,
      message,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type,
      orderId,
      tokenNumber
    };
    setNotifications(prev => [newNotif, ...prev.slice(0, 8)]);
  };

  const dismissNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  // Order Placement
  const placeOrder = (paymentMethod: 'cash' | 'upi', specialInstructions?: string): Order => {
    // Generate next token number
    let nextNum = 103;
    try {
      const stored = localStorage.getItem('smart_canteen_token_counter');
      if (stored) {
        nextNum = parseInt(stored, 10) + 1;
      } else if (orders.length > 0) {
        const last = orders[0];
        const num = parseInt(last.tokenNumber.replace(/\D/g, ''), 10);
        if (!isNaN(num)) nextNum = num + 1;
      }
    } catch {
      nextNum = 104;
    }
    localStorage.setItem('smart_canteen_token_counter', String(nextNum));

    const tokenNumber = `CT-${nextNum}`;
    const user = currentUser || DEFAULT_STUDENT;
    const subtotal = cartSubtotal;

    // Pick appropriate pickup counter based on items
    const hasBeverageOnly = cart.every(ci => ci.item.category === 'Beverages');
    const hasMeals = cart.some(ci => ci.item.category === 'Lunch');
    const pickupCounter = hasBeverageOnly
      ? 'Counter #3 (Beverages & Juice Express)'
      : hasMeals
      ? 'Counter #2 (Thali & Meals)'
      : 'Counter #1 (Snacks & Quick Bites)';

    // Estimated preparation time based on maximum prep time in cart
    const maxItemPrep = Math.max(...cart.map(c => c.item.prepTimeMinutes), 5);
    const estimatedMinutes = maxItemPrep + 2;

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      tokenNumber,
      userId: user.id,
      userName: user.name,
      userPhone: user.phone,
      rollNumber: user.rollNumber,
      items: [...cart],
      subtotal,
      convenienceFee: 0,
      total: subtotal,
      paymentMethod,
      paymentStatus: paymentMethod === 'upi' ? 'completed' : 'pending',
      status: 'placed',
      pickupCounter,
      createdAt: new Date().toISOString(),
      estimatedMinutes,
      specialInstructions: specialInstructions?.trim() || undefined,
      history: [
        {
          status: 'placed',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          label: 'Order Placed (Digital Token Issued)'
        }
      ]
    };

    setOrders(prev => [newOrder, ...prev]);
    clearCart();
    playCanteenChime('placed');

    pushNotification(
      `Order Placed: ${tokenNumber}`,
      `Token ${tokenNumber} generated. Approx ${estimatedMinutes} mins to prepare at ${pickupCounter.split(' ')[0]}.`,
      'order_placed',
      newOrder.id,
      tokenNumber
    );

    setActiveTab('tracker');
    return newOrder;
  };

  // Update status (Admin or simulation)
  const updateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    let targetToken = '';
    setOrders(prev => {
      return prev.map(ord => {
        if (ord.id === orderId) {
          targetToken = ord.tokenNumber;
          const statusLabels: Record<OrderStatus, string> = {
            placed: 'Order Placed',
            accepted: 'Kitchen Accepted Order',
            preparing: 'Live Preparation in Progress',
            ready: 'Ready for Pickup at Counter!',
            completed: 'Order Collected & Completed'
          };

          const newHistory = [
            ...ord.history,
            {
              status: newStatus,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              label: statusLabels[newStatus]
            }
          ];

          return {
            ...ord,
            status: newStatus,
            paymentStatus: newStatus === 'completed' && ord.paymentMethod === 'cash' ? 'completed' : ord.paymentStatus,
            history: newHistory
          };
        }
        return ord;
      });
    });

    if (newStatus === 'ready') {
      playCanteenChime('ready');
      pushNotification(
        `Token ${targetToken} Ready!`,
        `Please collect your food at the designated pickup counter.`,
        'order_status',
        orderId,
        targetToken
      );
    } else if (newStatus === 'accepted') {
      playCanteenChime('ping');
      pushNotification(
        `Order Accepted: ${targetToken}`,
        `Canteen kitchen started processing your food.`,
        'order_status',
        orderId,
        targetToken
      );
    } else if (newStatus === 'completed') {
      pushNotification(
        `Order ${targetToken} Completed`,
        `Thank you for using Smart Canteen! Enjoy your meal.`,
        'order_status',
        orderId,
        targetToken
      );
    }
  };

  // Admin menu operations
  const addMenuItem = (item: Omit<FoodItem, 'id'>) => {
    const newItem: FoodItem = {
      ...item,
      id: `food-${Date.now()}`
    };
    setMenu(prev => [newItem, ...prev]);
    pushNotification('Menu Updated', `Added "${newItem.name}" to canteen menu.`, 'info');
  };

  const updateMenuItem = (updatedItem: FoodItem) => {
    setMenu(prev => prev.map(item => (item.id === updatedItem.id ? updatedItem : item)));
    pushNotification('Menu Updated', `Updated details for "${updatedItem.name}".`, 'info');
  };

  const deleteMenuItem = (itemId: string) => {
    const item = menu.find(i => i.id === itemId);
    setMenu(prev => prev.filter(i => i.id !== itemId));
    pushNotification('Item Deleted', `Removed "${item?.name || 'Item'}" from menu.`, 'info');
  };

  const toggleItemAvailability = (itemId: string) => {
    setMenu(prev => {
      return prev.map(i => {
        if (i.id === itemId) {
          const nextState = !i.available;
          pushNotification(
            'Availability Changed',
            `${i.name} is now ${nextState ? 'IN STOCK' : 'OUT OF STOCK'}.`,
            'info'
          );
          return { ...i, available: nextState };
        }
        return i;
      });
    });
  };

  const resetDefaultMenu = () => {
    setMenu(INITIAL_FOOD_MENU);
    localStorage.setItem('smart_canteen_menu', JSON.stringify(INITIAL_FOOD_MENU));
    pushNotification('Menu Reset', 'Restored original college canteen menu items.', 'info');
  };

  const generateSampleOrder = () => {
    let nextNum = 105;
    try {
      const stored = localStorage.getItem('smart_canteen_token_counter');
      if (stored) nextNum = parseInt(stored, 10) + 1;
    } catch {
      nextNum = 105;
    }
    localStorage.setItem('smart_canteen_token_counter', String(nextNum));

    const sampleOrder: Order = {
      id: `ord-demo-${Date.now()}`,
      tokenNumber: `CT-${nextNum}`,
      userId: 'usr-student-sample',
      userName: 'Priya Sharma (Student)',
      userPhone: '9876543210',
      rollNumber: '22IT018',
      items: [
        { item: menu[0] || INITIAL_FOOD_MENU[0], quantity: 2 },
        { item: menu[7] || INITIAL_FOOD_MENU[7], quantity: 1 }
      ],
      subtotal: 50,
      convenienceFee: 0,
      total: 50,
      paymentMethod: 'upi',
      paymentStatus: 'completed',
      status: 'placed',
      pickupCounter: 'Counter #1 (Snacks & Quick Bites)',
      createdAt: new Date().toISOString(),
      estimatedMinutes: 8,
      specialInstructions: 'Make sambar spicy.',
      history: [
        {
          status: 'placed',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          label: 'Order Placed (Demo Student)'
        }
      ]
    };
    setOrders(prev => [sampleOrder, ...prev]);
    playCanteenChime('placed');
    pushNotification(
      'New Kitchen Order!',
      `Incoming order ${sampleOrder.tokenNumber} from Priya Sharma.`,
      'order_placed'
    );
  };

  return (
    <CanteenContext.Provider
      value={{
        currentUser,
        allUsers,
        menu,
        cart,
        orders,
        notifications,
        activeTab,
        setActiveTab,
        isAuthModalOpen,
        setIsAuthModalOpen,
        authMode,
        setAuthMode,
        loginRolePreference,
        setLoginRolePreference,
        login,
        register,
        quickLoginAs,
        logout,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        placeOrder,
        updateOrderStatus,
        addMenuItem,
        updateMenuItem,
        deleteMenuItem,
        toggleItemAvailability,
        resetDefaultMenu,
        generateSampleOrder,
        dismissNotification,
        cartTotalCount,
        cartSubtotal
      }}
    >
      {children}
    </CanteenContext.Provider>
  );
};

export const useCanteen = () => {
  const context = useContext(CanteenContext);
  if (!context) {
    throw new Error('useCanteen must be used within a CanteenProvider');
  }
  return context;
};
