import React, { useState } from 'react';
import { CanteenProvider, useCanteen } from './context/CanteenContext';
import { Header } from './components/Header';
import { StudentDashboard } from './components/StudentDashboard';
import { CartDrawer } from './components/CartDrawer';
import { LiveOrderTracker } from './components/LiveOrderTracker';
import { OrderHistoryView } from './components/OrderHistoryView';
import { AdminDashboard } from './components/AdminDashboard';
import { AuthModal } from './components/AuthModal';
import { MiniProjectCodeModal } from './components/MiniProjectCodeModal';
import { 
  BellRing, 
  X, 
  Utensils, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  Code2,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

const CanteenMainContent: React.FC = () => {
  const { 
    activeTab, 
    notifications, 
    dismissNotification, 
    currentUser,
    setActiveTab 
  } = useCanteen();

  const [isCodeModalOpen, setIsCodeModalOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-[#FFFBF7]">
      {/* Top Header */}
      <Header onOpenCodeModal={() => setIsCodeModalOpen(true)} />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {activeTab === 'menu' && <StudentDashboard />}
        {activeTab === 'cart' && <CartDrawer />}
        {activeTab === 'tracker' && <LiveOrderTracker />}
        {activeTab === 'orders' && <OrderHistoryView />}
        {activeTab === 'admin' && <AdminDashboard />}
      </main>

      {/* In-App Toast Notifications (Bottom Right) */}
      <aside aria-label="Notifications" className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
        {notifications.slice(0, 3).map(notif => (
          <div
            key={notif.id}
            className="pointer-events-auto bg-slate-900 text-white p-3.5 rounded-2xl shadow-2xl border border-slate-700/80 flex items-start gap-3 animate-in slide-in-from-bottom-3 duration-300"
          >
            <div className="w-8 h-8 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center shrink-0 mt-0.5">
              {notif.type === 'order_status' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              ) : notif.type === 'order_placed' ? (
                <BellRing className="w-4 h-4 text-amber-400" />
              ) : (
                <Utensils className="w-4 h-4 text-orange-400" />
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <strong className="text-xs font-bold text-white truncate">{notif.title}</strong>
                <span className="text-[10px] text-slate-400 shrink-0">{notif.time}</span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5 leading-snug">{notif.message}</p>
              {notif.tokenNumber && (
                <button
                  onClick={() => {
                    setActiveTab('tracker');
                    dismissNotification(notif.id);
                  }}
                  className="mt-1 text-[11px] font-bold text-orange-400 hover:text-orange-300 underline"
                >
                  View Token #{notif.tokenNumber} &rarr;
                </button>
              )}
            </div>

            <button
              onClick={() => dismissNotification(notif.id)}
              className="text-slate-400 hover:text-white p-1 shrink-0"
              title="Dismiss"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </aside>

      {/* Footer */}
      <footer className="bg-white border-t border-orange-100/80 py-8 text-xs text-slate-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-orange-500 text-white flex items-center justify-center font-bold text-xs">
                  SC
                </div>
                <strong className="text-sm font-bold text-slate-900">Smart Canteen</strong>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                Campus Online Food Ordering & Digital Token Queue System designed to eliminate lunchtime congestion.
              </p>
            </div>

            <div className="space-y-1.5">
              <strong className="text-xs font-bold text-slate-900 block uppercase tracking-wider">Canteen Timings</strong>
              <div className="text-xs text-slate-500 space-y-1">
                <div>Breakfast: 07:30 AM – 11:00 AM</div>
                <div>Lunch: 12:00 PM – 03:00 PM</div>
                <div>Snacks & Tea: 03:30 PM – 06:30 PM</div>
              </div>
            </div>

            <div className="space-y-1.5">
              <strong className="text-xs font-bold text-slate-900 block uppercase tracking-wider">Pickup Counters</strong>
              <div className="text-xs text-slate-500 space-y-1">
                <div>Counter 1: Snacks, Bakery & Fast Food</div>
                <div>Counter 2: South Indian Thali & Meals</div>
                <div>Counter 3: Hot Coffee, Tea & Juice</div>
              </div>
            </div>

            <div className="space-y-2">
              <strong className="text-xs font-bold text-slate-900 block uppercase tracking-wider">Mini-Project Info</strong>
              <p className="text-xs text-slate-500">
                Academic prototype using HTML, CSS, JavaScript, and localStorage. Includes Simulated UPI payments.
              </p>
              <button
                onClick={() => setIsCodeModalOpen(true)}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-orange-600 hover:text-orange-700 underline"
              >
                <Code2 className="w-3.5 h-3.5" />
                <span>View Standalone Files (HTML/CSS/JS)</span>
              </button>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-400 text-[11px]">
            <div>
              &copy; {new Date().getFullYear()} Smart Canteen System · College Mini-Project Demonstration
            </div>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1 text-emerald-600 font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" />
                Simulated Sandbox
              </span>
              <span>·</span>
              <span>No Real Payment Gateways Required</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Global Modals */}
      <AuthModal />
      <MiniProjectCodeModal 
        isOpen={isCodeModalOpen} 
        onClose={() => setIsCodeModalOpen(false)} 
      />
    </div>
  );
};

export default function App() {
  return (
    <CanteenProvider>
      <CanteenMainContent />
    </CanteenProvider>
  );
}
